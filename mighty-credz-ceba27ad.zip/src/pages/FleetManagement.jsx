import React, { useState, useEffect } from "react";
import { User, Vehicle, FuelTransaction } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Car, Plus, Fuel, TrendingUp, MapPin } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function FleetManagement() {
  const [vehicles, setVehicles] = useState([]);
  const [recentFuelTransactions, setRecentFuelTransactions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadFleetData();
  }, []);

  const loadFleetData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      const userVehicles = await Vehicle.filter({ owner_id: currentUser.id }, "-created_date");
      setVehicles(userVehicles);
      
      const fuelTxs = await FuelTransaction.filter({ user_id: currentUser.id }, "-created_date", 10);
      setRecentFuelTransactions(fuelTxs);
    } catch (error) {
      console.error("Error loading fleet data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const totalRebatesEarned = recentFuelTransactions.reduce((sum, tx) => sum + (tx.total_rebate || 0), 0);
  const totalFuelSpent = recentFuelTransactions.reduce((sum, tx) => sum + (tx.total_amount || 0), 0);

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <motion.div
          
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("Dashboard")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Fleet Management</h1>
            <p className="text-gray-600">Manage vehicles, track fuel, and earn rebates</p>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <motion.div
            
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            
          >
            <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-none shadow-xl">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100 text-sm">Total Vehicles</p>
                    <p className="text-3xl font-bold">{vehicles.length}</p>
                  </div>
                  <Car className="w-8 h-8 text-blue-200" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            
          >
            <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white border-none shadow-xl">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100 text-sm">Fuel Rebates</p>
                    <p className="text-3xl font-bold">{totalRebatesEarned.toFixed(2)}</p>
                    <p className="text-green-200 text-xs">CRz Earned</p>
                  </div>
                  <Fuel className="w-8 h-8 text-green-200" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            
          >
            <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-none shadow-xl">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100 text-sm">Fuel Spent</p>
                    <p className="text-3xl font-bold">{totalFuelSpent.toFixed(2)}</p>
                    <p className="text-purple-200 text-xs">CRz Total</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-purple-200" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            
          >
            <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white border-none shadow-xl">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-100 text-sm">Savings Rate</p>
                    <p className="text-3xl font-bold">
                      {totalFuelSpent > 0 ? ((totalRebatesEarned / totalFuelSpent) * 100).toFixed(1) : 0}%
                    </p>
                    <p className="text-orange-200 text-xs">Rebate %</p>
                  </div>
                  <MapPin className="w-8 h-8 text-orange-200" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Vehicle List */}
          <motion.div
            
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            
          >
            <Card className="bg-white/90 backdrop-blur-sm border-none shadow-xl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl font-bold">Your Vehicles</CardTitle>
                  <Link to={createPageUrl("AddVehicle")}>
                    <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Vehicle
                    </Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                {vehicles.length === 0 ? (
                  <div className="text-center py-8">
                    <Car className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">No Vehicles Added</h3>
                    <p className="text-gray-600 mb-4">Add your first vehicle to start tracking fuel and earning rebates</p>
                    <Link to={createPageUrl("AddVehicle")}>
                      <Button>Add Your First Vehicle</Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {vehicles.map((vehicle, index) => (
                      <motion.div
                        key={vehicle.id}
                        
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: index * 0.1 }}
                        
                        className="p-4 border rounded-lg hover:shadow-md transition-shadow cursor-pointer"
                        onClick={() => window.location.href = createPageUrl(`VehicleDetails?id=${vehicle.id}`)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                              <Car className="w-6 h-6 text-blue-600" />
                            </div>
                            <div>
                              <h3 className="font-semibold text-gray-900">{vehicle.number_plate}</h3>
                              <p className="text-sm text-gray-600">{vehicle.make} {vehicle.model}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <Badge className={vehicle.ownership_type === 'company' ? 'bg-purple-100 text-purple-800' : 'bg-green-100 text-green-800'}>
                              {vehicle.ownership_type}
                            </Badge>
                            <p className="text-sm text-gray-500 mt-1">{vehicle.current_mileage || 0} km</p>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Recent Fuel Transactions */}
          <motion.div
            
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            
          >
            <Card className="bg-white/90 backdrop-blur-sm border-none shadow-xl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl font-bold">Recent Fuel Purchases</CardTitle>
                  <Link to={createPageUrl("FuelPurchase")}>
                    <Button variant="outline">
                      <Fuel className="w-4 h-4 mr-2" />
                      Add Fuel
                    </Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                {recentFuelTransactions.length === 0 ? (
                  <div className="text-center py-8">
                    <Fuel className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">No Fuel Records</h3>
                    <p className="text-gray-600 mb-4">Start tracking your fuel purchases to earn rebates</p>
                    <Link to={createPageUrl("FuelPurchase")}>
                      <Button>Record Fuel Purchase</Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {recentFuelTransactions.slice(0, 5).map((transaction, index) => (
                      <motion.div
                        key={transaction.id}
                        
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: index * 0.1 }}
                        
                        className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                            <Fuel className="w-5 h-5 text-green-600" />
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{transaction.liters}L {transaction.fuel_type}</p>
                            <p className="text-sm text-gray-500">{transaction.retailer_name}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-gray-900">{transaction.total_amount} CRz</p>
                          <p className="text-sm text-green-600">+{transaction.total_rebate} CRz rebate</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}