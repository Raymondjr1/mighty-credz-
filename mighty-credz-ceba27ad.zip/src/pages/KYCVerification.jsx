import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { UploadPrivateFile } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, ShieldCheck, UploadCloud, CheckCircle, Clock, XCircle, FileText } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function KYCVerification() {
  const [user, setUser] = useState(null);
  const [idFile, setIdFile] = useState(null);
  const [addressFile, setAddressFile] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [error, setError] = useState("");
  const [uploadProgress, setUploadProgress] = useState({ id: 0, address: 0 });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (e) {
        setError("You must be logged in to verify your account.");
      } finally {
        setIsLoadingUser(false);
      }
    };
    fetchUser();
  }, []);

  const handleFileChange = (e, fileType) => {
    const file = e.target.files[0];
    if (fileType === 'id') setIdFile(file);
    if (fileType === 'address') setAddressFile(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!idFile || !addressFile) {
      setError("Please upload both documents.");
      return;
    }
    setIsLoading(true);
    setError("");

    try {
      // In a real app, you might use a progress callback from the upload function
      const idUploadResult = await UploadPrivateFile({ file: idFile });
      setUploadProgress({ id: 50, address: 0 });
      const addressUploadResult = await UploadPrivateFile({ file: addressFile });
      setUploadProgress({ id: 100, address: 100 });
      
      await User.updateMyUserData({
        id_document_uri: idUploadResult.file_uri,
        proof_of_address_uri: addressUploadResult.file_uri,
        kyc_status: 'pending'
      });

      // Refetch user to update UI
      const updatedUser = await User.me();
      setUser(updatedUser);

    } catch (err) {
      setError("An error occurred during upload. Please try again.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const StatusDisplay = ({ status }) => {
    switch (status) {
      case 'verified':
        return (
          <div className="text-center py-12">
            <CheckCircle className="w-16 h-16 mx-auto text-green-500 mb-4" />
            <h3 className="text-2xl font-bold text-gray-900">You are Verified!</h3>
            <p className="text-gray-600 mt-2">Your account is fully verified. Thank you for completing the KYC process.</p>
          </div>
        );
      case 'pending':
        return (
          <div className="text-center py-12">
            <Clock className="w-16 h-16 mx-auto text-yellow-500 mb-4" />
            <h3 className="text-2xl font-bold text-gray-900">Verification Pending</h3>
            <p className="text-gray-600 mt-2">Your documents have been submitted and are under review. This usually takes 1-2 business days.</p>
          </div>
        );
      case 'rejected':
        return (
          <div className="text-center py-12">
            <XCircle className="w-16 h-16 mx-auto text-red-500 mb-4" />
            <h3 className="text-2xl font-bold text-gray-900">Verification Rejected</h3>
            <p className="text-gray-600 mt-2">There was an issue with your documents. Please check your messages for details and resubmit.</p>
             <Button onClick={() => setUser(prev => ({...prev, kyc_status: 'unverified'}))} className="mt-4">Resubmit Documents</Button>
          </div>
        );
      default:
        return null;
    }
  };

  if (isLoadingUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your account...</p>
        </div>
      </div>
    );
  }

  if (error && !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md mx-auto text-center bg-white/90 backdrop-blur-sm border-none shadow-2xl">
          <CardContent className="p-8">
            <XCircle className="w-16 h-16 mx-auto text-red-500 mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Authentication Required</h2>
            <p className="text-gray-600 mb-6">{error}</p>
            <Link to={createPageUrl("Dashboard")}>
              <Button className="w-full">Go to Dashboard</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("Dashboard")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">KYC Verification</h1>
            <p className="text-gray-600">Secure your account by verifying your identity.</p>
          </div>
        </motion.div>
        
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="mighty-surface mighty-shadow border-none">
            {user && user.kyc_status !== 'unverified' ? (
              <CardContent className="p-6">
                <StatusDisplay status={user.kyc_status} />
              </CardContent>
            ) : (
              <>
                <CardHeader>
                  <CardTitle>Submit Your Documents</CardTitle>
                  <CardDescription>Upload a valid ID and proof of address to complete verification.</CardDescription>
                </CardHeader>
                <CardContent>
                  {error && <Alert variant="destructive" className="mb-4"><AlertDescription>{error}</AlertDescription></Alert>}
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="id-file">Identity Document (ID Card, Passport)</Label>
                      <Input id="id-file" type="file" onChange={(e) => handleFileChange(e, 'id')} required />
                      {idFile && <p className="text-sm text-gray-500 flex items-center gap-2 pt-2"><FileText className="w-4 h-4" /> {idFile.name}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="address-file">Proof of Address (Utility Bill, Bank Statement)</Label>
                      <Input id="address-file" type="file" onChange={(e) => handleFileChange(e, 'address')} required />
                      {addressFile && <p className="text-sm text-gray-500 flex items-center gap-2 pt-2"><FileText className="w-4 h-4" /> {addressFile.name}</p>}
                    </div>
                    <Alert>
                      <ShieldCheck className="h-4 w-4" />
                      <AlertDescription>Your documents are encrypted and stored securely. They will only be used for verification purposes.</AlertDescription>
                    </Alert>
                    <Button type="submit" disabled={isLoading} className="w-full mighty-button-primary text-lg py-6">
                      {isLoading ? (
                        <div className="flex items-center gap-2">
                          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          Submitting...
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <UploadCloud className="w-5 h-5" />
                          Submit for Verification
                        </div>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </>
            )}
          </Card>
        </motion.div>
      </div>
    </div>
  );
}