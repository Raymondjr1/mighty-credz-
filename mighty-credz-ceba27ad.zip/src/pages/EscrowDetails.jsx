
import React, { useState, useEffect, useCallback } from "react";
import { User, EscrowAccount, TradeDocument } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Shield, Clock, CheckCircle, AlertTriangle, FileText, Upload, Download, MessageSquare } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { format } from "date-fns";

export default function EscrowDetails() {
  const [escrow, setEscrow] = useState(null);
  const [user, setUser] = useState(null);
  const [documents, setDocuments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const loadEscrowDetails = useCallback(async (escrowId) => {
    try {
      const currentUser = await User.me();
      if (currentUser.escrow_access_status !== 'approved') {
        navigate(createPageUrl("EscrowManagement"));
        return;
      }
      setUser(currentUser);

      const escrowData = await EscrowAccount.filter({ id: escrowId });
      if (escrowData.length > 0) {
        setEscrow(escrowData[0]);
        
        const docs = await TradeDocument.filter({ escrow_id: escrowId });
        setDocuments(docs);
      } else {
        setError("Escrow not found");
      }
    } catch (error) {
      setError("Failed to load escrow details");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  }, [navigate]);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const escrowId = urlParams.get('id');
    if (escrowId) {
      loadEscrowDetails(escrowId);
    }
  }, [loadEscrowDetails]);

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'funded': case 'goods_shipped': return 'bg-blue-100 text-blue-800';
      case 'disputed': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'disputed': return <AlertTriangle className="w-5 h-5 text-red-600" />;
      case 'pending': case 'funded': return <Clock className="w-5 h-5 text-blue-600" />;
      default: return <Shield className="w-5 h-5 text-gray-600" />;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading escrow details...</p>
        </div>
      </div>
    );
  }

  if (error || !escrow) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md mx-auto text-center">
          <CardContent className="p-8">
            <AlertTriangle className="w-16 h-16 mx-auto text-red-500 mb-4" />
            <h2 className="text-xl font-bold text-gray-900 mb-2">Error</h2>
            <p className="text-gray-600 mb-4">{error}</p>
            <Link to={createPageUrl("EscrowManagement")}>
              <Button>Back to Escrow Management</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  if (!user || !escrow) {
    // This state could be hit briefly if user is null while isLoading is false,
    // before the access check or initial data load is complete.
    // Or if access was denied and navigate was called, but component hasn't unmounted yet.
    return (
       <div className="min-h-screen flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-teal-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("EscrowManagement")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-gray-900">{escrow.title}</h1>
            <p className="text-gray-600">Escrow ID: {escrow.escrow_id}</p>
          </div>
          <Badge className={`${getStatusColor(escrow.status)} text-lg px-4 py-2`}>
            {getStatusIcon(escrow.status)}
            <span className="ml-2">{escrow.status.replace('_', ' ').toUpperCase()}</span>
          </Badge>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Details */}
          <div className="lg:col-span-2 space-y-6">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <Card className="mighty-surface mighty-shadow border-none">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="w-5 h-5 text-teal-600" />
                    Transaction Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Buyer</h4>
                      <p className="text-gray-600">{escrow.buyer_name}</p>
                      <p className="text-sm text-gray-500">
                        {user?.id === escrow.buyer_id ? "You" : "Other Party"}
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Seller</h4>
                      <p className="text-gray-600">{escrow.seller_name}</p>
                      <p className="text-sm text-gray-500">
                        {user?.id === escrow.seller_id ? "You" : "Other Party"}
                      </p>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <h4 className="font-semibold text-gray-900 mb-2">Description</h4>
                    <p className="text-gray-600">{escrow.goods_description}</p>
                  </div>

                  {escrow.terms_conditions && (
                    <div className="border-t pt-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Terms & Conditions</h4>
                      <p className="text-gray-600">{escrow.terms_conditions}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Documents Section */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
              <Card className="mighty-surface mighty-shadow border-none">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-teal-600" />
                    Trade Documents
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {documents.length === 0 ? (
                    <div className="text-center py-8">
                      <FileText className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                      <p className="text-gray-500">No documents uploaded yet</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {documents.map((doc) => (
                        <div key={doc.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center gap-3">
                            <FileText className="w-5 h-5 text-blue-500" />
                            <div>
                              <p className="font-medium">{doc.document_name}</p>
                              <p className="text-sm text-gray-500">{doc.document_type.replace('_', ' ')}</p>
                            </div>
                          </div>
                          <Badge variant={doc.status === 'approved' ? 'default' : 'secondary'}>
                            {doc.status.replace('_', ' ')}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Financial Summary */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
              <Card className="mighty-surface mighty-shadow border-none">
                <CardHeader>
                  <CardTitle>Financial Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Amount:</span>
                    <span className="font-bold">{escrow.transaction_amount.toFixed(2)} {escrow.currency}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Escrow Fee:</span>
                    <span>{escrow.escrow_fee.toFixed(2)} {escrow.currency}</span>
                  </div>
                  <div className="border-t pt-3">
                    <div className="flex justify-between text-lg font-bold">
                      <span>Total:</span>
                      <span>{(escrow.transaction_amount + escrow.escrow_fee).toFixed(2)} {escrow.currency}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Timeline */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
              <Card className="mighty-surface mighty-shadow border-none">
                <CardHeader>
                  <CardTitle>Transaction Timeline</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">Escrow Created</p>
                      <p className="text-sm text-gray-500">{format(new Date(escrow.created_date), 'MMM d, yyyy')}</p>
                    </div>
                  </div>
                  
                  {escrow.funded_date && (
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <CheckCircle className="w-4 h-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium">Funds Deposited</p>
                        <p className="text-sm text-gray-500">{format(new Date(escrow.funded_date), 'MMM d, yyyy')}</p>
                      </div>
                    </div>
                  )}
                  
                  {escrow.expected_delivery_date && (
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                        <Clock className="w-4 h-4 text-yellow-600" />
                      </div>
                      <div>
                        <p className="font-medium">Expected Delivery</p>
                        <p className="text-sm text-gray-500">{format(new Date(escrow.expected_delivery_date), 'MMM d, yyyy')}</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Actions */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }}>
              <Card className="mighty-surface mighty-shadow border-none">
                <CardHeader>
                  <CardTitle>Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button className="w-full mighty-button-primary" disabled={escrow.status === 'completed'}>
                    <MessageSquare className="w-4 h-4 mr-2" />
                    Contact Other Party
                  </Button>
                  {escrow.status === 'pending' && user?.id === escrow.buyer_id && (
                    <Button variant="outline" className="w-full">
                      <Shield className="w-4 h-4 mr-2" />
                      Fund Escrow
                    </Button>
                  )}
                  {escrow.requires_documents && (
                    <Button variant="outline" className="w-full">
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Documents
                    </Button>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
