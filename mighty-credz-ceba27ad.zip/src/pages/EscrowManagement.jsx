
import React, { useState, useEffect, useCallback } from "react";
import { User, EscrowAccount } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Shield, Plus, Clock, CheckCircle, AlertTriangle, Globe, Package, FileText, Users, Lock, Rocket } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { format } from "date-fns";

export default function EscrowManagement() {
  const [escrowAccounts, setEscrowAccounts] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [accessStatus, setAccessStatus] = useState('loading'); // loading, approved, pending, requires_application
  const navigate = useNavigate();

  const loadData = useCallback(async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      if (currentUser.escrow_access_status === 'approved') {
        setAccessStatus('approved');
        const escrows = await EscrowAccount.filter({
          $or: [
            { buyer_id: currentUser.id },
            { seller_id: currentUser.id }
          ]
        }, "-created_date", 50);
        setEscrowAccounts(escrows);
      } else {
        setAccessStatus(currentUser.escrow_access_status || 'none');
        // Redirect to application page if access is not approved
        navigate(createPageUrl("EscrowApplication"));
      }
    } catch (error) {
      console.error("Error loading escrow data:", error);
      setAccessStatus('error');
    } finally {
      setIsLoading(false);
    }
  }, [navigate]); // Added navigate to useCallback dependencies

  useEffect(() => {
    loadData();
  }, [loadData]); // Added loadData to useEffect dependencies

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'funded': case 'goods_shipped': return 'bg-blue-100 text-blue-800';
      case 'disputed': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'cancelled': case 'refunded': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'disputed': return <AlertTriangle className="w-4 h-4 text-red-600" />;
      case 'pending': case 'funded': return <Clock className="w-4 h-4 text-blue-600" />;
      default: return <Shield className="w-4 h-4 text-gray-600" />;
    }
  };

  const getTransactionTypeIcon = (type) => {
    switch (type) {
      case 'international_trade': return <Globe className="w-5 h-5" />;
      case 'ecommerce': return <Package className="w-5 h-5" />;
      case 'freelance': return <Users className="w-5 h-5" />;
      default: return <FileText className="w-5 h-5" />;
    }
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-teal-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  // Gatekeeper render. This part will be briefly visible before redirection.
  if (accessStatus !== 'approved') {
     return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="text-center">
          <p>Redirecting to Escrow Application...</p>
        </div>
      </div>
    );
  }

  const stats = {
    total: escrowAccounts.length,
    active: escrowAccounts.filter(e => ['pending', 'funded', 'goods_shipped'].includes(e.status)).length,
    completed: escrowAccounts.filter(e => e.status === 'completed').length,
    disputed: escrowAccounts.filter(e => e.status === 'disputed').length,
    totalValue: escrowAccounts.reduce((sum, e) => sum + e.transaction_amount, 0)
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Dashboard")}>
              <Button variant="outline" size="icon" className="rounded-full">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Escrow Management</h1>
              <p className="text-gray-600">Secure transactions for international trade & ecommerce</p>
            </div>
          </div>
          <Link to={createPageUrl("CreateEscrow")}>
            <Button className="mighty-button-primary">
              <Plus className="w-4 h-4 mr-2" />
              New Escrow
            </Button>
          </Link>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <Card className="mighty-surface mighty-shadow border-none">
              <CardContent className="p-4 text-center">
                <Shield className="w-8 h-8 mx-auto text-teal-600 mb-2" />
                <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
                <p className="text-xs text-gray-600">Total Escrows</p>
              </CardContent>
            </Card>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <Card className="mighty-surface mighty-shadow border-none">
              <CardContent className="p-4 text-center">
                <Clock className="w-8 h-8 mx-auto text-blue-600 mb-2" />
                <p className="text-2xl font-bold text-gray-900">{stats.active}</p>
                <p className="text-xs text-gray-600">Active</p>
              </CardContent>
            </Card>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            <Card className="mighty-surface mighty-shadow border-none">
              <CardContent className="p-4 text-center">
                <CheckCircle className="w-8 h-8 mx-auto text-green-600 mb-2" />
                <p className="text-2xl font-bold text-gray-900">{stats.completed}</p>
                <p className="text-xs text-gray-600">Completed</p>
              </CardContent>
            </Card>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
            <Card className="mighty-surface mighty-shadow border-none">
              <CardContent className="p-4 text-center">
                <AlertTriangle className="w-8 h-8 mx-auto text-red-600 mb-2" />
                <p className="text-2xl font-bold text-gray-900">{stats.disputed}</p>
                <p className="text-xs text-gray-600">Disputed</p>
              </CardContent>
            </Card>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
            <Card className="mighty-surface mighty-shadow border-none">
              <CardContent className="p-4 text-center">
                <Globe className="w-8 h-8 mx-auto text-purple-600 mb-2" />
                <p className="text-2xl font-bold text-gray-900">{stats.totalValue.toFixed(0)}</p>
                <p className="text-xs text-gray-600">Total Value CRz</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Escrow Transactions */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
          <Card className="mighty-surface mighty-shadow border-none">
            <CardHeader>
              <CardTitle>Your Escrow Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              {escrowAccounts.length === 0 ? (
                <div className="text-center py-12">
                  <Shield className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No Escrow Transactions</h3>
                  <p className="text-gray-600 mb-4">Start your first secure transaction</p>
                  <Link to={createPageUrl("CreateEscrow")}>
                    <Button className="mighty-button-primary">Create Escrow</Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-4">
                  {escrowAccounts.map((escrow, index) => (
                    <motion.div
                      key={escrow.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="p-4 border border-gray-200 rounded-xl hover:shadow-md transition-all cursor-pointer"
                      onClick={() => navigate(createPageUrl(`EscrowDetails?id=${escrow.id}`))}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3 flex-1">
                          <div className="w-12 h-12 bg-gradient-to-br from-teal-100 to-blue-100 rounded-xl flex items-center justify-center">
                            {getTransactionTypeIcon(escrow.transaction_type)}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-semibold text-gray-900">{escrow.title}</h3>
                              <Badge className={getStatusColor(escrow.status)}>
                                {getStatusIcon(escrow.status)}
                                <span className="ml-1">{escrow.status.replace('_', ' ')}</span>
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-600 mb-1">
                              {user?.id === escrow.buyer_id ? `Buying from ${escrow.seller_name}` : `Selling to ${escrow.buyer_name}`}
                            </p>
                            <p className="text-sm text-gray-500">
                              {escrow.transaction_type.replace('_', ' ')} • Created {format(new Date(escrow.created_date), 'MMM d, yyyy')}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-gray-900">{escrow.transaction_amount.toFixed(2)} {escrow.currency}</p>
                          <p className="text-sm text-gray-500">
                            {escrow.expected_delivery_date && `Due: ${format(new Date(escrow.expected_delivery_date), 'MMM d')}`}
                          </p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
