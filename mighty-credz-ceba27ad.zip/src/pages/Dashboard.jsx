import React, { useState, useEffect } from "react";
import { User, Transaction } from "@/api/entities";
import { motion } from "framer-motion";

import WalletCard from "../components/dashboard/WalletCard";
import QuickActions from "../components/dashboard/QuickActions";
import RecentActivity from "../components/dashboard/RecentActivity";

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showBalance, setShowBalance] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      const userTransactions = await Transaction.filter(
        { 
          $or: [
            { from_user_id: currentUser.id },
            { to_user_id: currentUser.id }
          ]
        },
        "-created_date",
        10
      );
      setTransactions(userTransactions);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <motion.div
          
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          
          className="text-center md:text-left"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
            Welcome back{user?.full_name ? `, ${user.full_name.split(' ')[0]}` : ''}!
          </h1>
          <p className="text-gray-600 text-lg">
            Manage your money, communications, and rewards all in one place
          </p>
        </motion.div>

        {/* Wallet Card */}
        <WalletCard 
          balance={user?.wallet_balance || 0}
          showBalance={showBalance}
          setShowBalance={setShowBalance}
        />

        {/* Quick Actions */}
        <div>
          <motion.h2
            
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            
            className="text-2xl font-bold text-gray-900 mb-6"
          >
            Quick Actions
          </motion.h2>
          <QuickActions />
        </div>

        {/* Recent Activity */}
        <div>
          <motion.h2
            
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            
            className="text-2xl font-bold text-gray-900 mb-6"
          >
            Recent Activity
          </motion.h2>
          <RecentActivity 
            transactions={transactions}
            isLoading={isLoading}
          />
        </div>
      </div>
    </div>
  );
}