import React, { useState, useEffect } from "react";
import { User, Transaction } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Gift, Star, Share2, Copy, MessageCircle, Facebook } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { format } from "date-fns";

export default function Rewards() {
  const [user, setUser] = useState(null);
  const [loyaltyTransactions, setLoyaltyTransactions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      const txs = await Transaction.filter(
        { 
          from_user_id: currentUser.id,
          loyalty_points_earned: { $gt: 0 }
        },
        "-created_date", 
        20
      );
      setLoyaltyTransactions(txs);

    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleShare = (platform) => {
    const referralCode = user?.referral_code || "JOIN_MIGHTY";
    const text = `Join me on Mighty Mobile and let's start saving! Use my code: ${referralCode} to sign up.`;
    const url = "https://mightymobile.app"; // Replace with actual app URL
    const encodedText = encodeURIComponent(text);
    const encodedUrl = encodeURIComponent(url);

    let shareUrl;
    if (platform === 'whatsapp') {
      shareUrl = `https://wa.me/?text=${encodedText}%20${encodedUrl}`;
    } else if (platform === 'facebook') {
      shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodedText}`;
    }

    if (shareUrl) {
      window.open(shareUrl, '_blank');
    }
  };

  const handleCopyCode = () => {
    if (user?.referral_code) {
      navigator.clipboard.writeText(user.referral_code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };
  
  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("Dashboard")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Loyalty & Referrals</h1>
            <p className="text-gray-600">Earn points on purchases and rewards for inviting friends.</p>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <Card className="bg-gradient-to-br from-purple-500 to-pink-600 text-white border-none shadow-xl">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">Total Loyalty Points</p>
                    <p className="text-4xl font-bold">{user?.total_loyalty_points || 0}</p>
                  </div>
                  <Star className="w-8 h-8 text-purple-200" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <Card className="bg-gradient-to-br from-teal-500 to-cyan-600 text-white border-none shadow-xl">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-teal-100">Referral Earnings (TLC)</p>
                    <p className="text-4xl font-bold">{(user?.total_referral_earnings || 0).toFixed(2)}</p>
                    <p className="text-teal-200 text-xs">CRz Earned</p>
                  </div>
                  <Gift className="w-8 h-8 text-teal-200" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Refer & Earn Card */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="mighty-surface mighty-shadow border-none mb-8">
            <CardHeader>
              <CardTitle>Invite Friends, Earn Rewards (TLC)</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Share your referral code. You'll earn a commission every time someone in your network transacts on Mighty Mobile!</p>
              <div className="flex items-center gap-2 p-3 bg-gray-100 rounded-lg mb-4">
                <span className="flex-1 text-gray-800 font-mono">{user?.referral_code || '...'}</span>
                <Button size="sm" variant="ghost" onClick={handleCopyCode}>
                  <Copy className="w-4 h-4 mr-2"/>
                  {copied ? 'Copied!' : 'Copy'}
                </Button>
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <Button onClick={() => handleShare('whatsapp')} className="flex-1 bg-green-500 hover:bg-green-600 text-white">
                  <MessageCircle className="w-5 h-5 mr-2" /> Share on WhatsApp
                </Button>
                <Button onClick={() => handleShare('facebook')} className="flex-1 bg-blue-600 hover:bg-blue-700 text-white">
                  <Share2 className="w-5 h-5 mr-2" /> Share on Facebook
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Recent Loyalty Activity */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card className="mighty-surface mighty-shadow border-none">
            <CardHeader>
              <CardTitle>Recent Loyalty Activity</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <p>Loading activity...</p>
              ) : loyaltyTransactions.length === 0 ? (
                <div className="text-center py-8">
                  <Star className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No Loyalty Points Earned Yet</h3>
                  <p className="text-gray-600">Start making purchases with Mighty Mobile to earn points.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {loyaltyTransactions.map(tx => (
                    <div key={tx.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-800">{tx.description}</p>
                        <p className="text-sm text-gray-500">{format(new Date(tx.created_date), "MMM d, yyyy")}</p>
                      </div>
                      <Badge className="bg-purple-100 text-purple-800 text-base">
                        +{tx.loyalty_points_earned} pts
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

      </div>
    </div>
  );
}