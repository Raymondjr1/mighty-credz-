import React, { useState, useEffect } from "react";
import { User, Wallet, Transaction } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Wallet as WalletIcon, Plus, ArrowUpDown, Settings, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function MultiWallet() {
  const [wallets, setWallets] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newWallet, setNewWallet] = useState({
    name: "",
    wallet_type: "",
    spending_limit: "",
    auto_top_up_amount: ""
  });

  useEffect(() => {
    loadWallets();
  }, []);

  const loadWallets = async () => {
    try {
      const currentUser = await User.me();
      const userWallets = await Wallet.filter({ owner_id: currentUser.id }, "-created_date");
      setWallets(userWallets);
    } catch (error) {
      console.error("Error loading wallets:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateWallet = async (e) => {
    e.preventDefault();
    try {
      const currentUser = await User.me();
      await Wallet.create({
        owner_id: currentUser.id,
        name: newWallet.name,
        wallet_type: newWallet.wallet_type,
        balance: 0,
        spending_limit: parseFloat(newWallet.spending_limit) || null,
        auto_top_up_amount: parseFloat(newWallet.auto_top_up_amount) || null
      });
      
      setShowCreateForm(false);
      setNewWallet({ name: "", wallet_type: "", spending_limit: "", auto_top_up_amount: "" });
      loadWallets();
    } catch (error) {
      console.error("Error creating wallet:", error);
    }
  };

  const getWalletIcon = (type) => {
    const icons = {
      main: "💼",
      daily: "🛒",
      kids: "🎒",
      partner: "💕",
      fuel: "⛽",
      business: "🏢",
      savings: "🏦"
    };
    return icons[type] || "💰";
  };

  const getWalletColor = (type) => {
    const colors = {
      main: "bg-blue-100 text-blue-800 border-blue-200",
      daily: "bg-green-100 text-green-800 border-green-200",
      kids: "bg-purple-100 text-purple-800 border-purple-200",
      partner: "bg-pink-100 text-pink-800 border-pink-200",
      fuel: "bg-orange-100 text-orange-800 border-orange-200",
      business: "bg-indigo-100 text-indigo-800 border-indigo-200",
      savings: "bg-emerald-100 text-emerald-800 border-emerald-200"
    };
    return colors[type] || "bg-gray-100 text-gray-800 border-gray-200";
  };

  const totalBalance = wallets.reduce((sum, wallet) => sum + (wallet.balance || 0), 0);

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <motion.div
          
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("Dashboard")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Multi-Wallet System</h1>
            <p className="text-gray-600">Organize your CREDz across multiple dedicated wallets</p>
          </div>
        </motion.div>

        {/* Total Balance Card */}
        <motion.div
          
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          
          className="mb-8"
        >
          <Card className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white border-none shadow-2xl">
            <CardContent className="p-8">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-200 text-lg">Total Balance Across All Wallets</p>
                  <p className="text-5xl font-bold mt-2">{totalBalance.toFixed(2)} CRz</p>
                  <p className="text-blue-200 mt-2">{wallets.length} Active Wallets</p>
                </div>
                <div className="text-6xl opacity-20">💰</div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Create Wallet Button */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Your Wallets</h2>
          <Button 
            onClick={() => setShowCreateForm(true)}
            className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create New Wallet
          </Button>
        </div>

        {/* Create Wallet Form */}
        {showCreateForm && (
          <motion.div
            
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            
            className="mb-8"
          >
            <Card className="bg-white/90 backdrop-blur-sm border-none shadow-xl">
              <CardHeader>
                <CardTitle>Create New Wallet</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleCreateWallet} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="wallet_name">Wallet Name</Label>
                      <Input
                        id="wallet_name"
                        placeholder="e.g., Kids School Money"
                        value={newWallet.name}
                        onChange={(e) => setNewWallet(prev => ({ ...prev, name: e.target.value }))}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="wallet_type">Wallet Type</Label>
                      <Select 
                        value={newWallet.wallet_type} 
                        onValueChange={(value) => setNewWallet(prev => ({ ...prev, wallet_type: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select wallet type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="daily">Daily Purchases</SelectItem>
                          <SelectItem value="kids">Kids</SelectItem>
                          <SelectItem value="partner">Partner</SelectItem>
                          <SelectItem value="fuel">Fuel</SelectItem>
                          <SelectItem value="business">Business</SelectItem>
                          <SelectItem value="savings">Savings</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="spending_limit">Daily Spending Limit (CRz)</Label>
                      <Input
                        id="spending_limit"
                        type="number"
                        step="0.01"
                        placeholder="500.00"
                        value={newWallet.spending_limit}
                        onChange={(e) => setNewWallet(prev => ({ ...prev, spending_limit: e.target.value }))}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="auto_top_up">Auto Top-up Amount (CRz)</Label>
                      <Input
                        id="auto_top_up"
                        type="number"
                        step="0.01"
                        placeholder="200.00"
                        value={newWallet.auto_top_up_amount}
                        onChange={(e) => setNewWallet(prev => ({ ...prev, auto_top_up_amount: e.target.value }))}
                      />
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <Button type="submit" className="flex-1">Create Wallet</Button>
                    <Button type="button" variant="outline" onClick={() => setShowCreateForm(false)}>
                      Cancel
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Wallets Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(6).fill(0).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-20 bg-gray-200 rounded mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-6 bg-gray-200 rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : wallets.length === 0 ? (
          <motion.div
            
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            
          >
            <Card className="text-center py-12 bg-white/80 backdrop-blur-sm border-none shadow-lg">
              <CardContent>
                <WalletIcon className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No Wallets Created</h3>
                <p className="text-gray-600 mb-6">
                  Create dedicated wallets for different purposes - daily spending, kids, partner, fuel, etc.
                </p>
                <Button 
                  onClick={() => setShowCreateForm(true)}
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                >
                  Create Your First Wallet
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {wallets.map((wallet, index) => (
              <motion.div
                key={wallet.id}
                
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                
              >
                <Card className="bg-white/90 backdrop-blur-sm border-none shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="text-3xl">{getWalletIcon(wallet.wallet_type)}</div>
                      {wallet.is_primary && (
                        <Badge className="bg-yellow-100 text-yellow-800">Primary</Badge>
                      )}
                    </div>
                    
                    <h3 className="font-bold text-lg text-gray-900 mb-2">{wallet.name}</h3>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Balance:</span>
                        <span className="font-bold text-xl">{(wallet.balance || 0).toFixed(2)} CRz</span>
                      </div>
                      
                      {wallet.spending_limit && (
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-gray-500">Daily Limit:</span>
                          <span className="text-gray-700">{wallet.spending_limit} CRz</span>
                        </div>
                      )}
                      
                      <Badge className={getWalletColor(wallet.wallet_type)} variant="outline">
                        {wallet.wallet_type.replace('_', ' ')}
                      </Badge>
                    </div>
                    
                    <div className="flex gap-2 mt-4">
                      <Button size="sm" variant="outline" className="flex-1">
                        <ArrowUpDown className="w-3 h-3 mr-1" />
                        Transfer
                      </Button>
                      <Button size="sm" variant="outline">
                        <Settings className="w-3 h-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}

        {/* Tips */}
        <motion.div
          
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          
          className="mt-8"
        >
          <Alert>
            <WalletIcon className="h-4 w-4" />
            <AlertDescription>
              <strong>Multi-Wallet Benefits:</strong> Organize your spending with dedicated wallets. 
              Set spending limits for kids' school purchases, partner allowances, or fuel budgets. 
              Enable auto top-up to never run out of funds when you need them most.
            </AlertDescription>
          </Alert>
        </motion.div>
      </div>
    </div>
  );
}