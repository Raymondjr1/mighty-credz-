import React, { useState, useEffect } from "react";
import { User, Transaction, PayrollRun, PayrollEmployeePayment } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ArrowLeft, CheckCircle, AlertCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function RunPayroll() {
  const [employees, setEmployees] = useState([]);
  const [salaries, setSalaries] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [company, setCompany] = useState(null);
  const [payrollResult, setPayrollResult] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const currentUser = await User.me();
        setCompany(currentUser);
        const companyEmployees = await User.filter({ parent_company_id: currentUser.id });
        setEmployees(companyEmployees);
        const initialSalaries = companyEmployees.reduce((acc, emp) => ({ ...acc, [emp.id]: "" }), {});
        setSalaries(initialSalaries);
      } catch (error) {
        console.error("Error fetching employee data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleSalaryChange = (employeeId, amount) => {
    setSalaries(prev => ({ ...prev, [employeeId]: amount }));
  };

  const totalPayroll = Object.values(salaries).reduce((sum, s) => sum + (parseFloat(s) || 0), 0);

  const handleRunPayroll = async () => {
    if (totalPayroll <= 0) {
      setError("Total payroll must be greater than zero.");
      return;
    }
    if (company.wallet_balance < totalPayroll) {
      setError(`Insufficient funds. Payroll requires ${totalPayroll.toFixed(2)} CRz, but you only have ${company.wallet_balance.toFixed(2)} CRz.`);
      return;
    }
    if (!window.confirm(`You are about to run payroll for ${totalPayroll.toFixed(2)} CRz. This action cannot be undone. Continue?`)) {
      return;
    }

    setIsProcessing(true);
    setError("");

    try {
      const companyBalanceBefore = company.wallet_balance;
      let totalPaid = 0;
      let employeesPaid = 0;
      
      const payrollRun = await PayrollRun.create({
          company_id: company.id,
          run_date: new Date().toISOString(),
          total_amount: totalPayroll,
          employee_count: Object.keys(salaries).filter(id => parseFloat(salaries[id]) > 0).length,
          status: 'pending' // intermediate status
      });

      for (const employee of employees) {
        const salaryAmount = parseFloat(salaries[employee.id]);
        if (salaryAmount > 0) {
          // This would ideally be a single backend transaction
          const tx = await Transaction.create({
            from_user_id: company.id,
            to_user_id: employee.id,
            amount: salaryAmount,
            type: 'send',
            description: `Salary payment for ${new Date().toLocaleString('default', { month: 'long', year: 'numeric' })}`
          });
          
          const employeeUser = await User.get(employee.id);
          await User.update(employee.id, { wallet_balance: (employeeUser.wallet_balance || 0) + salaryAmount });
          
          await PayrollEmployeePayment.create({
              payroll_run_id: payrollRun.id,
              employee_id: employee.id,
              amount: salaryAmount,
              status: 'success',
              transaction_id: tx.id
          });

          totalPaid += salaryAmount;
          employeesPaid++;
        }
      }

      await User.updateMyUserData({ wallet_balance: companyBalanceBefore - totalPaid });
      
      await PayrollRun.update(payrollRun.id, { status: 'completed' });

      setPayrollResult({ success: true, totalPaid, employeesPaid });
    } catch (err) {
      setError("A critical error occurred during payroll processing. Please contact support.");
      console.error(err);
      setPayrollResult({ success: false, error: err.message });
    } finally {
      setIsProcessing(false);
    }
  };

  if (payrollResult) {
    return (
        <div className="min-h-screen flex items-center justify-center p-4">
            <Card className="max-w-md mx-auto text-center mighty-surface">
                <CardContent className="p-8">
                    {payrollResult.success ? (
                        <>
                            <CheckCircle className="w-16 h-16 mx-auto text-green-500 mb-4" />
                            <h2 className="text-2xl font-bold">Payroll Complete!</h2>
                            <p className="text-gray-600 mt-2">
                                Successfully paid <strong>{payrollResult.totalPaid.toFixed(2)} CRz</strong> to <strong>{payrollResult.employeesPaid}</strong> employees.
                            </p>
                        </>
                    ) : (
                        <>
                            <AlertCircle className="w-16 h-16 mx-auto text-red-500 mb-4" />
                            <h2 className="text-2xl font-bold">Payroll Failed</h2>
                            <p className="text-gray-600 mt-2">{payrollResult.error || "An unexpected error occurred."}</p>
                        </>
                    )}
                    <Link to={createPageUrl("CompanyDashboard")} className="mt-6 block">
                        <Button className="w-full">Back to Company Hub</Button>
                    </Link>
                </CardContent>
            </Card>
        </div>
    )
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("CompanyDashboard")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Run Payroll</h1>
            <p className="text-gray-600">Enter salary amounts and pay your employees.</p>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            {isLoading ? <p>Loading...</p> : employees.map((employee, index) => (
              <motion.div
                key={employee.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="mighty-surface">
                  <CardContent className="p-4 flex items-center justify-between">
                    <div>
                      <p className="font-bold">{employee.full_name}</p>
                      <p className="text-sm text-gray-500">{employee.email}</p>
                    </div>
                    <div className="w-40">
                      <Input
                        type="number"
                        placeholder="0.00"
                        className="text-right font-semibold"
                        value={salaries[employee.id] || ""}
                        onChange={(e) => handleSalaryChange(employee.id, e.target.value)}
                      />
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="lg:col-span-1">
            <Card className="sticky top-8 mighty-surface mighty-shadow">
              <CardHeader>
                <CardTitle>Payroll Summary</CardTitle>
                <CardDescription>Review before processing.</CardDescription>
              </CardHeader>
              <CardContent>
                {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Company Balance:</span>
                    <span className="font-medium">{(company?.wallet_balance || 0).toFixed(2)} CRz</span>
                  </div>
                  <div className="flex justify-between items-center text-lg">
                    <span className="font-bold">Total Payroll:</span>
                    <span className="font-bold text-green-600">{totalPayroll.toFixed(2)} CRz</span>
                  </div>
                   <div className="flex justify-between items-center">
                    <span className="text-gray-600">Balance After:</span>
                    <span className="font-medium">{((company?.wallet_balance || 0) - totalPayroll).toFixed(2)} CRz</span>
                  </div>
                  <Button 
                    className="w-full mighty-button-primary py-6 text-lg"
                    onClick={handleRunPayroll}
                    disabled={isProcessing || totalPayroll <= 0}
                  >
                    {isProcessing ? "Processing..." : "Confirm & Pay"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}