import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Shield, CheckCircle, Clock, XCircle, Rocket, Globe, FileText, Users, Building } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';

export default function EscrowApplication() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    company_name: '',
    company_reg_number: '',
    company_website: '',
    company_address: '',
    company_business_description: '',
    company_escrow_application_reason: '',
  });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
        setFormData({
          company_name: currentUser.company_name || '',
          company_reg_number: currentUser.company_reg_number || '',
          company_website: currentUser.company_website || '',
          company_address: currentUser.company_address || '',
          company_business_description: currentUser.company_business_description || '',
          company_escrow_application_reason: currentUser.company_escrow_application_reason || '',
        });
      } catch (error) {
        console.error("Failed to fetch user", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchUser();
  }, []);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await User.updateMyUserData({ 
        ...formData,
        escrow_access_status: 'applied' 
      });
      const updatedUser = await User.me();
      setUser(updatedUser);
    } catch (error) {
      console.error("Failed to submit application", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderContent = () => {
    if (isLoading) {
      return <div className="text-center p-8">Loading...</div>;
    }

    switch (user?.escrow_access_status) {
      case 'approved':
        return (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Card className="text-center p-8 mighty-surface mighty-shadow">
              <CheckCircle className="w-16 h-16 mx-auto text-green-500 mb-4" />
              <h2 className="text-2xl font-bold">Access Approved!</h2>
              <p className="text-gray-600 mt-2 mb-6">You have full access to our premium escrow services.</p>
              <Link to={createPageUrl("EscrowManagement")}>
                <Button className="mighty-button-primary">Go to Escrow Dashboard</Button>
              </Link>
            </Card>
          </motion.div>
        );
      case 'applied':
        return (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Card className="p-8 mighty-surface mighty-shadow">
              <div className="text-center">
                <Clock className="w-16 h-16 mx-auto text-blue-500 mb-4" />
                <h2 className="text-2xl font-bold">Application Under Review</h2>
                <p className="text-gray-600 mt-2 mb-6">Your application for escrow services is currently being reviewed. This process typically takes 1-2 business days. We'll notify you upon approval.</p>
              </div>
              <Card className="bg-slate-50 p-4 mt-6">
                <CardHeader>
                  <CardTitle className="text-lg">Your Submitted Information</CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-2">
                  <p><strong>Company Name:</strong> {user.company_name}</p>
                  <p><strong>Registration No:</strong> {user.company_reg_number}</p>
                  <p><strong>Website:</strong> {user.company_website}</p>
                </CardContent>
              </Card>
            </Card>
          </motion.div>
        );
      case 'rejected':
      case 'none':
      default:
        return (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Card className="mighty-surface mighty-shadow border-none">
              <CardHeader className="text-center p-6">
                <Rocket className="w-12 h-12 mx-auto text-teal-500 mb-2" />
                <CardTitle className="text-2xl font-bold">Unlock Premium Escrow Services</CardTitle>
                <CardDescription>Secure your high-value transactions for international trade and e-commerce.</CardDescription>
                {user?.escrow_access_status === 'rejected' && (
                  <p className="text-red-500 font-semibold mt-2 bg-red-50 p-3 rounded-lg">Your previous application was not approved. Please review your company details and reapply.</p>
                )}
              </CardHeader>
              <CardContent className="p-6">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label htmlFor="company_name">Company Name</Label>
                      <Input id="company_name" value={formData.company_name} onChange={handleInputChange} required />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="company_reg_number">Company Registration No.</Label>
                      <Input id="company_reg_number" value={formData.company_reg_number} onChange={handleInputChange} required />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="company_website">Company Website</Label>
                    <Input id="company_website" placeholder="https://..." type="url" value={formData.company_website} onChange={handleInputChange} />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="company_address">Business Address</Label>
                    <Textarea id="company_address" value={formData.company_address} onChange={handleInputChange} />
                  </div>
                   <div className="space-y-1">
                    <Label htmlFor="company_business_description">Briefly describe your business</Label>
                    <Textarea id="company_business_description" value={formData.company_business_description} onChange={handleInputChange} required />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="company_escrow_application_reason">Why do you need escrow services?</Label>
                    <Textarea id="company_escrow_application_reason" placeholder="e.g., Importing electronics from China, exporting crafts to the US..." value={formData.company_escrow_application_reason} onChange={handleInputChange} required />
                  </div>
                  <Button type="submit" disabled={isSubmitting} className="w-full mt-4 mighty-button-primary text-lg py-6">
                    {isSubmitting ? 'Submitting...' : 'Submit Application'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        );
    }
  };
  
  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("Dashboard")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Escrow Service Application</h1>
            <p className="text-gray-600">For Premium Members & Companies</p>
          </div>
        </motion.div>
        {renderContent()}
      </div>
    </div>
  );
}