import React, { useState, useEffect } from "react";
import { User, Transaction } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, QrCode, Camera, CheckCircle, AlertCircle, Send } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function ScanToPay() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const [scanResult, setScanResult] = useState(null);
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await User.me();
        if (!currentUser.qr_code_identifier) {
          const identifier = `MIGHTY-MOBILE-PAY-${currentUser.id}-${Date.now()}`;
          await User.updateMyUserData({ qr_code_identifier: identifier });
          setUser({ ...currentUser, qr_code_identifier: identifier });
        } else {
          setUser(currentUser);
        }
      } catch (e) {
        setError("Failed to load user data.");
      } finally {
        setIsLoading(false);
      }
    };
    loadUser();
  }, []);

  const handleSimulateScan = () => {
    // In a real app, this would come from a QR scanner library
    setScanResult({
      name: "John Doe (Demo)",
      phone: "+15551234568",
    });
  };

  const handlePayment = async () => {
    setIsLoading(true);
    setError("");
    try {
      const amount = parseFloat(paymentAmount);
      if (!amount || amount <= 0) throw new Error("Invalid amount");
      if (user.wallet_balance < amount) throw new Error("Insufficient funds");

      await Transaction.create({
        from_user_id: user.id,
        to_phone_number: scanResult.phone,
        amount: amount,
        type: "send",
        payment_method: "qr_scan",
        description: `QR Payment to ${scanResult.name}`,
      });

      await User.updateMyUserData({
        wallet_balance: user.wallet_balance - amount,
      });

      setPaymentSuccess(true);
    } catch (e) {
      setError(e.message);
    } finally {
      setIsLoading(false);
    }
  };

  const qrCodeUrl = user?.qr_code_identifier
    ? `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(
        JSON.stringify({
          name: user.full_name,
          phone: user.phone_number,
          id: user.qr_code_identifier,
        })
      )}`
    : "";
    
  if (paymentSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
          <Card className="max-w-md mx-auto text-center shadow-2xl">
            <CardContent className="p-8">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <h2 className="text-2xl font-bold mb-2">Payment Successful!</h2>
              <p className="text-gray-600 mb-6">
                You sent {paymentAmount} CRz to {scanResult.name}.
              </p>
              <Button onClick={() => { setPaymentSuccess(false); setScanResult(null); setPaymentAmount(""); }} className="w-full">
                Make Another Payment
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-md mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("Dashboard")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Scan to Pay</h1>
            <p className="text-gray-600">Pay or get paid instantly with QR codes</p>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} delay={0.2}>
          <Tabs defaultValue="my_code" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="my_code">My QR Code</TabsTrigger>
              <TabsTrigger value="scan">Scan & Pay</TabsTrigger>
            </TabsList>
            <TabsContent value="my_code">
              <Card className="mt-4 shadow-xl">
                <CardHeader className="text-center">
                  <CardTitle>Receive Money</CardTitle>
                  <p className="text-gray-500">Let others scan this code to pay you.</p>
                </CardHeader>
                <CardContent className="flex flex-col items-center gap-6">
                  {isLoading ? (
                    <div className="w-64 h-64 bg-gray-200 animate-pulse rounded-lg"></div>
                  ) : (
                    <div className="p-4 bg-white rounded-lg border">
                      <img src={qrCodeUrl} alt="Your Payment QR Code" />
                    </div>
                  )}
                  <div className="text-center">
                    <p className="font-bold text-lg">{user?.full_name}</p>
                    <p className="text-gray-600">{user?.phone_number}</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="scan">
              <Card className="mt-4 shadow-xl">
                <CardHeader>
                  <CardTitle>Scan a Code to Pay</CardTitle>
                </CardHeader>
                <CardContent>
                  {scanResult ? (
                    <div className="space-y-4">
                       <h3 className="text-lg font-medium text-center">Pay {scanResult.name}</h3>
                       <p className="text-center text-gray-500 -mt-2">{scanResult.phone}</p>
                       {error && <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>{error}</AlertDescription></Alert>}
                       <div className="space-y-2">
                         <Label htmlFor="amount">Amount (CRz)</Label>
                         <Input
                           id="amount"
                           type="number"
                           placeholder="0.00"
                           value={paymentAmount}
                           onChange={(e) => setPaymentAmount(e.target.value)}
                           className="text-2xl text-center font-bold h-16"
                           required
                         />
                       </div>
                       <Button onClick={handlePayment} disabled={isLoading} className="w-full py-6 text-lg">
                         <Send className="w-5 h-5 mr-2"/>
                         {isLoading ? "Processing..." : "Confirm & Pay"}
                       </Button>
                       <Button variant="outline" onClick={() => setScanResult(null)} className="w-full">Cancel</Button>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center text-center p-8 border-2 border-dashed rounded-lg">
                      <Camera className="w-16 h-16 text-gray-300 mb-4" />
                      <p className="text-gray-500 mb-4">Point your camera at a QR code to pay.</p>
                      <Button onClick={handleSimulateScan}>
                        <QrCode className="w-4 h-4 mr-2" />
                        Simulate Scan
                      </Button>
                      <p className="text-xs text-gray-400 mt-4">(This is a demo. In a real app, the camera would open here.)</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}