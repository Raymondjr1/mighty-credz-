
import React, { useState, useEffect, useCallback } from "react";
import { User, EscrowAccount } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, Shield, CheckCircle, AlertCircle, Plus, Minus } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function CreateEscrow() {
  const [formData, setFormData] = useState({
    title: "",
    transaction_type: "",
    buyer_name: "",
    seller_name: "",
    transaction_amount: "",
    currency: "CRz",
    goods_description: "",
    terms_conditions: "",
    shipping_terms: "",
    expected_delivery_date: "",
    inspection_period_days: "7",
    auto_release: true,
    requires_documents: false,
    required_documents: [],
    milestones: []
  });
  
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const [currentStep, setCurrentStep] = useState(1);
  const navigate = useNavigate();

  const loadUser = useCallback(async () => {
    try {
      const currentUser = await User.me();
      if (currentUser.escrow_access_status !== 'approved') {
        navigate(createPageUrl("EscrowManagement"));
        return;
      }
      setUser(currentUser);
    } catch (error) {
      setError("Please log in to create escrow");
    }
  }, [navigate]);

  useEffect(() => {
    loadUser();
  }, [loadUser]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addMilestone = () => {
    setFormData(prev => ({
      ...prev,
      milestones: [...prev.milestones, { description: "", amount: "", status: "pending" }]
    }));
  };

  const removeMilestone = (index) => {
    setFormData(prev => ({
      ...prev,
      milestones: prev.milestones.filter((_, i) => i !== index)
    }));
  };

  const updateMilestone = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      milestones: prev.milestones.map((milestone, i) => 
        i === index ? { ...milestone, [field]: value } : milestone
      )
    }));
  };

  const addRequiredDocument = (docType) => {
    if (!formData.required_documents.includes(docType)) {
      setFormData(prev => ({
        ...prev,
        required_documents: [...prev.required_documents, docType]
      }));
    }
  };

  const removeRequiredDocument = (docType) => {
    setFormData(prev => ({
      ...prev,
      required_documents: prev.required_documents.filter(doc => doc !== docType)
    }));
  };

  const calculateEscrowFee = () => {
    const amount = parseFloat(formData.transaction_amount) || 0;
    return Math.max(amount * 0.025, 5); // 2.5% fee, minimum 5 CRz
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    try {
      if (!user) throw new Error("User not found");
      
      const escrowId = `ESC-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`.toUpperCase();
      const escrowFee = calculateEscrowFee();

      const escrowData = {
        escrow_id: escrowId,
        buyer_id: user.id,
        seller_id: null, // Will be filled when seller accepts
        buyer_name: formData.buyer_name || user.full_name,
        seller_name: formData.seller_name,
        transaction_amount: parseFloat(formData.transaction_amount),
        currency: formData.currency,
        escrow_fee: escrowFee,
        transaction_type: formData.transaction_type,
        title: formData.title,
        goods_description: formData.goods_description,
        terms_conditions: formData.terms_conditions,
        shipping_terms: formData.shipping_terms,
        expected_delivery_date: formData.expected_delivery_date,
        inspection_period_days: parseInt(formData.inspection_period_days),
        auto_release: formData.auto_release,
        requires_documents: formData.requires_documents,
        required_documents: formData.required_documents,
        milestones: formData.milestones.map(m => ({
          ...m,
          amount: parseFloat(m.amount) || 0
        })),
        status: "pending"
      };

      await EscrowAccount.create(escrowData);
      setSuccess(true);

    } catch (error) {
      setError(error.message || "Failed to create escrow");
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md mx-auto text-center"
        >
          <Card className="mighty-surface mighty-shadow border-none">
            <CardContent className="p-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Escrow Created!</h2>
              <p className="text-gray-600 mb-6">
                Your escrow transaction has been created successfully. You can now share the escrow ID with the seller.
              </p>
              <div className="space-y-3">
                <Link to={createPageUrl("EscrowManagement")}>
                  <Button className="w-full mighty-button-primary">View Escrow</Button>
                </Link>
                <Button variant="outline" onClick={() => setSuccess(false)} className="w-full">
                  Create Another
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  const documentTypes = [
    "invoice", "bill_of_lading", "certificate_of_origin", "packing_list", 
    "inspection_certificate", "insurance_certificate", "customs_declaration", "letter_of_credit"
  ];

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-teal-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("EscrowManagement")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Create Escrow Transaction</h1>
            <p className="text-gray-600">Secure your international trade & ecommerce deals</p>
          </div>
        </motion.div>

        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-between max-w-2xl mx-auto">
            {[1, 2, 3].map((step) => (
              <div key={step} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  currentStep >= step ? 'bg-teal-600 text-white' : 'bg-gray-200 text-gray-600'
                }`}>
                  {step}
                </div>
                {step < 3 && (
                  <div className={`w-16 h-1 ${
                    currentStep > step ? 'bg-teal-600' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between max-w-2xl mx-auto mt-2 text-sm text-gray-600">
            <span>Basic Info</span>
            <span>Terms & Conditions</span>
            <span>Documents & Review</span>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="mighty-surface mighty-shadow border-none">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-teal-600" />
                {currentStep === 1 && "Transaction Details"}
                {currentStep === 2 && "Terms & Milestones"}
                {currentStep === 3 && "Documents & Final Review"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {error && (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Step 1: Basic Information */}
                {currentStep === 1 && (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="transaction_type">Transaction Type *</Label>
                        <Select value={formData.transaction_type} onValueChange={(value) => handleInputChange('transaction_type', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select transaction type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="international_trade">International Trade</SelectItem>
                            <SelectItem value="ecommerce">E-commerce</SelectItem>
                            <SelectItem value="freelance">Freelance Services</SelectItem>
                            <SelectItem value="real_estate">Real Estate</SelectItem>
                            <SelectItem value="vehicle_sale">Vehicle Sale</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="title">Transaction Title *</Label>
                        <Input
                          id="title"
                          placeholder="e.g., Import of Electronic Components"
                          value={formData.title}
                          onChange={(e) => handleInputChange('title', e.target.value)}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="buyer_name">Buyer Name *</Label>
                        <Input
                          id="buyer_name"
                          placeholder="Buyer/Importer name"
                          value={formData.buyer_name}
                          onChange={(e) => handleInputChange('buyer_name', e.target.value)}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="seller_name">Seller Name *</Label>
                        <Input
                          id="seller_name"
                          placeholder="Seller/Exporter name"
                          value={formData.seller_name}
                          onChange={(e) => handleInputChange('seller_name', e.target.value)}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="transaction_amount">Transaction Amount *</Label>
                        <Input
                          id="transaction_amount"
                          type="number"
                          step="0.01"
                          placeholder="0.00"
                          value={formData.transaction_amount}
                          onChange={(e) => handleInputChange('transaction_amount', e.target.value)}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="currency">Currency</Label>
                        <Select value={formData.currency} onValueChange={(value) => handleInputChange('currency', value)}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="CRz">CRz (Mighty Mobile)</SelectItem>
                            <SelectItem value="USD">USD</SelectItem>
                            <SelectItem value="EUR">EUR</SelectItem>
                            <SelectItem value="ZAR">ZAR</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="goods_description">Goods/Services Description *</Label>
                      <Textarea
                        id="goods_description"
                        placeholder="Detailed description of goods or services being transacted"
                        value={formData.goods_description}
                        onChange={(e) => handleInputChange('goods_description', e.target.value)}
                        rows={4}
                        required
                      />
                    </div>

                    {formData.transaction_amount && (
                      <Alert>
                        <Shield className="h-4 w-4" />
                        <AlertDescription>
                          <strong>Escrow Fee:</strong> {calculateEscrowFee().toFixed(2)} {formData.currency} (2.5% of transaction amount, minimum 5 {formData.currency})
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                )}

                {/* Step 2: Terms & Conditions */}
                {currentStep === 2 && (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="shipping_terms">Shipping Terms</Label>
                        <Select value={formData.shipping_terms} onValueChange={(value) => handleInputChange('shipping_terms', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select shipping terms" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="FOB">FOB (Free on Board)</SelectItem>
                            <SelectItem value="CIF">CIF (Cost, Insurance & Freight)</SelectItem>
                            <SelectItem value="EXW">EXW (Ex Works)</SelectItem>
                            <SelectItem value="DDP">DDP (Delivered Duty Paid)</SelectItem>
                            <SelectItem value="pickup">Pickup</SelectItem>
                            <SelectItem value="digital_delivery">Digital Delivery</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="expected_delivery_date">Expected Delivery Date</Label>
                        <Input
                          id="expected_delivery_date"
                          type="date"
                          value={formData.expected_delivery_date}
                          onChange={(e) => handleInputChange('expected_delivery_date', e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="inspection_period_days">Inspection Period (Days)</Label>
                        <Input
                          id="inspection_period_days"
                          type="number"
                          min="1"
                          max="30"
                          value={formData.inspection_period_days}
                          onChange={(e) => handleInputChange('inspection_period_days', e.target.value)}
                        />
                      </div>

                      <div className="flex items-center space-x-2 mt-8">
                        <Checkbox
                          id="auto_release"
                          checked={formData.auto_release}
                          onCheckedChange={(checked) => handleInputChange('auto_release', checked)}
                        />
                        <Label htmlFor="auto_release">Auto-release funds after inspection period</Label>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="terms_conditions">Terms & Conditions</Label>
                      <Textarea
                        id="terms_conditions"
                        placeholder="Specific terms and conditions for this transaction"
                        value={formData.terms_conditions}
                        onChange={(e) => handleInputChange('terms_conditions', e.target.value)}
                        rows={4}
                      />
                    </div>

                    {/* Milestones */}
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label>Payment Milestones (Optional)</Label>
                        <Button type="button" variant="outline" size="sm" onClick={addMilestone}>
                          <Plus className="w-4 h-4 mr-2" />
                          Add Milestone
                        </Button>
                      </div>
                      
                      {formData.milestones.map((milestone, index) => (
                        <div key={index} className="p-4 border rounded-lg space-y-3">
                          <div className="flex justify-between items-center">
                            <h4 className="font-medium">Milestone {index + 1}</h4>
                            <Button type="button" variant="ghost" size="sm" onClick={() => removeMilestone(index)}>
                              <Minus className="w-4 h-4" />
                            </Button>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <Input
                              placeholder="Milestone description"
                              value={milestone.description}
                              onChange={(e) => updateMilestone(index, 'description', e.target.value)}
                            />
                            <Input
                              type="number"
                              step="0.01"
                              placeholder="Amount"
                              value={milestone.amount}
                              onChange={(e) => updateMilestone(index, 'amount', e.target.value)}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Step 3: Documents & Review */}
                {currentStep === 3 && (
                  <div className="space-y-6">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="requires_documents"
                        checked={formData.requires_documents}
                        onCheckedChange={(checked) => handleInputChange('requires_documents', checked)}
                      />
                      <Label htmlFor="requires_documents">This transaction requires trade documents</Label>
                    </div>

                    {formData.requires_documents && (
                      <div className="space-y-4">
                        <Label>Required Documents</Label>
                        <div className="grid grid-cols-2 gap-3">
                          {documentTypes.map((docType) => (
                            <div key={docType} className="flex items-center space-x-2">
                              <Checkbox
                                id={docType}
                                checked={formData.required_documents.includes(docType)}
                                onCheckedChange={(checked) => {
                                  if (checked) {
                                    addRequiredDocument(docType);
                                  } else {
                                    removeRequiredDocument(docType);
                                  }
                                }}
                              />
                              <Label htmlFor={docType} className="text-sm capitalize">
                                {docType.replace('_', ' ')}
                              </Label>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Transaction Summary */}
                    <div className="bg-gray-50 p-6 rounded-lg space-y-4">
                      <h3 className="text-lg font-semibold">Transaction Summary</h3>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Type:</span>
                          <span className="ml-2 font-medium">{formData.transaction_type?.replace('_', ' ')}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Amount:</span>
                          <span className="ml-2 font-medium">{formData.transaction_amount} {formData.currency}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Escrow Fee:</span>
                          <span className="ml-2 font-medium">{calculateEscrowFee().toFixed(2)} {formData.currency}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Inspection Period:</span>
                          <span className="ml-2 font-medium">{formData.inspection_period_days} days</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Navigation Buttons */}
                <div className="flex justify-between pt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setCurrentStep(currentStep - 1)}
                    disabled={currentStep === 1}
                  >
                    Previous
                  </Button>
                  
                  {currentStep < 3 ? (
                    <Button
                      type="button"
                      onClick={() => setCurrentStep(currentStep + 1)}
                      disabled={
                        (currentStep === 1 && (!formData.title || !formData.transaction_type || !formData.transaction_amount)) ||
                        (currentStep === 2 && !formData.goods_description)
                      }
                      className="mighty-button-primary"
                    >
                      Next
                    </Button>
                  ) : (
                    <Button
                      type="submit"
                      disabled={isLoading}
                      className="mighty-button-primary"
                    >
                      {isLoading ? (
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          Creating...
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <Shield className="w-4 h-4" />
                          Create Escrow
                        </div>
                      )}
                    </Button>
                  )}
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
