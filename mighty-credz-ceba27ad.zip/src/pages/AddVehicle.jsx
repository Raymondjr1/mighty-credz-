import React, { useState } from "react";
import { User, Vehicle, Wallet } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Car, CheckCircle, AlertCircle } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function AddVehicle() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    number_plate: "",
    make: "",
    model: "",
    year: "",
    ownership_type: "",
    fuel_type: "",
    current_mileage: ""
  });
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");
    
    try {
      const currentUser = await User.me();
      
      // Create vehicle record
      await Vehicle.create({
        owner_id: currentUser.id,
        number_plate: formData.number_plate.toUpperCase(),
        make: formData.make,
        model: formData.model,
        year: parseInt(formData.year),
        ownership_type: formData.ownership_type,
        fuel_type: formData.fuel_type,
        current_mileage: parseInt(formData.current_mileage) || 0,
        last_fuel_mileage: parseInt(formData.current_mileage) || 0,
        company_id: formData.ownership_type === 'company' ? currentUser.parent_company_id : null
      });

      // Create a dedicated fuel wallet for this vehicle
      await Wallet.create({
        owner_id: currentUser.id,
        name: `${formData.number_plate} Fuel Wallet`,
        wallet_type: "fuel",
        balance: 0,
        spending_limit: 1000, // Default 1000 CRz daily limit
        auto_top_up: true,
        auto_top_up_amount: 500
      });
      
      setSuccess(true);
      
    } catch (error) {
      setError(error.message || "Failed to add vehicle");
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <motion.div
          
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          
        >
          <Card className="max-w-md mx-auto text-center bg-white/90 backdrop-blur-sm border-none shadow-2xl">
            <CardContent className="p-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Vehicle Added!</h2>
              <p className="text-gray-600 mb-6">
                {formData.number_plate} has been successfully added to your fleet. A dedicated fuel wallet has been created.
              </p>
              <div className="space-y-3">
                <Button 
                  onClick={() => navigate(createPageUrl("FleetManagement"))}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                >
                  View Fleet
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setSuccess(false)}
                  className="w-full"
                >
                  Add Another Vehicle
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <motion.div
          
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("FleetManagement")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Add Vehicle</h1>
            <p className="text-gray-600">Register a new vehicle to start earning fuel rebates</p>
          </div>
        </motion.div>

        <motion.div
          
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          
        >
          <Card className="bg-white/90 backdrop-blur-sm border-none shadow-xl">
            <CardHeader className="text-center pb-2">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Car className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl font-bold text-gray-900">
                Vehicle Registration
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <Alert className="mb-6">
                <Car className="h-4 w-4" />
                <AlertDescription>
                  <strong>Fuel Rebate Program:</strong> Earn 0.50 CRz rebate per liter when you fuel up at participating stations. 
                  Track your mileage to monitor efficiency and maximize savings.
                </AlertDescription>
              </Alert>

              {error && (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="number_plate">Number Plate *</Label>
                    <Input
                      id="number_plate"
                      placeholder="ABC-123-GP"
                      value={formData.number_plate}
                      onChange={(e) => handleInputChange('number_plate', e.target.value)}
                      className="uppercase"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="ownership_type">Ownership Type *</Label>
                    <Select value={formData.ownership_type} onValueChange={(value) => handleInputChange('ownership_type', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select ownership" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="personal">Personal Vehicle</SelectItem>
                        <SelectItem value="company">Company Vehicle</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="make">Make *</Label>
                    <Input
                      id="make"
                      placeholder="Toyota"
                      value={formData.make}
                      onChange={(e) => handleInputChange('make', e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="model">Model *</Label>
                    <Input
                      id="model"
                      placeholder="Corolla"
                      value={formData.model}
                      onChange={(e) => handleInputChange('model', e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="year">Year</Label>
                    <Input
                      id="year"
                      type="number"
                      min="1990"
                      max="2025"
                      placeholder="2020"
                      value={formData.year}
                      onChange={(e) => handleInputChange('year', e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="fuel_type">Fuel Type *</Label>
                    <Select value={formData.fuel_type} onValueChange={(value) => handleInputChange('fuel_type', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select fuel type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="petrol">Petrol</SelectItem>
                        <SelectItem value="diesel">Diesel</SelectItem>
                        <SelectItem value="hybrid">Hybrid</SelectItem>
                        <SelectItem value="electric">Electric</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="current_mileage">Current Mileage (km)</Label>
                    <Input
                      id="current_mileage"
                      type="number"
                      min="0"
                      placeholder="150000"
                      value={formData.current_mileage}
                      onChange={(e) => handleInputChange('current_mileage', e.target.value)}
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg"
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Adding Vehicle...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Car className="w-5 h-5" />
                      Add Vehicle to Fleet
                    </div>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}