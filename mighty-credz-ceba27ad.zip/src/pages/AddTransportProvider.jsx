import React, { useState } from "react";
import { TransportProvider } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Bus, Car, CheckCircle, AlertCircle, Plus } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function AddTransportProvider() {
  const [formData, setFormData] = useState({
    owner_name: "",
    phone_number: "",
    account_id: "",
    transport_type: "",
    vehicle_registration: "",
    route: "",
    company_name: ""
  });
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");
    
    try {
      await TransportProvider.create({
        ...formData,
        is_verified: false,
        is_active: true
      });
      
      setSuccess(true);
    } catch (error) {
      setError(error.message || "Failed to add transport provider");
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
          <Card className="max-w-md mx-auto text-center mighty-surface mighty-shadow-slate border-none">
            <CardContent className="p-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Provider Added!</h2>
              <p className="text-gray-600 mb-6">
                {formData.owner_name} has been added as a transport provider and can now receive payments through Mighty Mobile.
              </p>
              <div className="space-y-3">
                <Link to={createPageUrl("TransportPay")}>
                  <Button className="w-full mighty-button-primary">
                    Make Payment
                  </Button>
                </Link>
                <Button 
                  variant="outline" 
                  onClick={() => setSuccess(false)}
                  className="w-full"
                >
                  Add Another Provider
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("TransportPay")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Add Transport Provider</h1>
            <p className="text-gray-600">Register a new transport service provider</p>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card className="mighty-surface mighty-shadow border-none">
            <CardHeader className="text-center">
              <div className="w-16 h-16 mighty-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <Bus className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl font-bold text-gray-900">
                Transport Provider Registration
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <Alert className="mb-6">
                <Plus className="h-4 w-4" />
                <AlertDescription>
                  Register transport providers to enable seamless CRz payments with automatic transfer to their accounts.
                </AlertDescription>
              </Alert>

              {error && (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="owner_name">Driver/Owner Name *</Label>
                    <Input
                      id="owner_name"
                      placeholder="John Mbeki"
                      value={formData.owner_name}
                      onChange={(e) => handleInputChange('owner_name', e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone_number">Phone Number *</Label>
                    <Input
                      id="phone_number"
                      type="tel"
                      placeholder="+27 123 456 789"
                      value={formData.phone_number}
                      onChange={(e) => handleInputChange('phone_number', e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="transport_type">Transport Type *</Label>
                    <Select value={formData.transport_type} onValueChange={(value) => handleInputChange('transport_type', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select transport type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="taxi">Taxi</SelectItem>
                        <SelectItem value="kombi">Kombi</SelectItem>
                        <SelectItem value="bus">Bus</SelectItem>
                        <SelectItem value="uber">Uber</SelectItem>
                        <SelectItem value="bolt">Bolt</SelectItem>
                        <SelectItem value="private_transport">Private Transport</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="vehicle_registration">Vehicle Registration</Label>
                    <Input
                      id="vehicle_registration"
                      placeholder="ABC-123-GP"
                      value={formData.vehicle_registration}
                      onChange={(e) => handleInputChange('vehicle_registration', e.target.value.toUpperCase())}
                    />
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="route">Route/Area of Operation</Label>
                    <Input
                      id="route"
                      placeholder="e.g., Johannesburg CBD to Soweto"
                      value={formData.route}
                      onChange={(e) => handleInputChange('route', e.target.value)}
                    />
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="company_name">Company Name (Optional)</Label>
                    <Input
                      id="company_name"
                      placeholder="e.g., Metro Bus Company"
                      value={formData.company_name}
                      onChange={(e) => handleInputChange('company_name', e.target.value)}
                    />
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="account_id">Mighty Mobile Account ID (Optional)</Label>
                    <Input
                      id="account_id"
                      placeholder="If they have a Mighty Mobile account"
                      value={formData.account_id}
                      onChange={(e) => handleInputChange('account_id', e.target.value)}
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-6 text-lg font-semibold mighty-button-primary"
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Adding Provider...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Plus className="w-5 h-5" />
                      Add Transport Provider
                    </div>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}