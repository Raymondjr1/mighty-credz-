import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import SendMoney from "./SendMoney";

import Communications from "./Communications";

import Rewards from "./Rewards";

import History from "./History";

import BankDeposit from "./BankDeposit";

import RequestMoney from "./RequestMoney";

import FleetManagement from "./FleetManagement";

import AddVehicle from "./AddVehicle";

import MultiWallet from "./MultiWallet";

import ScanToPay from "./ScanToPay";

import TransportPay from "./TransportPay";

import AddTransportProvider from "./AddTransportProvider";

import KYCVerification from "./KYCVerification";

import LinkedAccounts from "./LinkedAccounts";

import CompanyDashboard from "./CompanyDashboard";

import ManageEmployees from "./ManageEmployees";

import RunPayroll from "./RunPayroll";

import EscrowManagement from "./EscrowManagement";

import CreateEscrow from "./CreateEscrow";

import EscrowDetails from "./EscrowDetails";

import EscrowApplication from "./EscrowApplication";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    SendMoney: SendMoney,
    
    Communications: Communications,
    
    Rewards: Rewards,
    
    History: History,
    
    BankDeposit: BankDeposit,
    
    RequestMoney: RequestMoney,
    
    FleetManagement: FleetManagement,
    
    AddVehicle: AddVehicle,
    
    MultiWallet: MultiWallet,
    
    ScanToPay: ScanToPay,
    
    TransportPay: TransportPay,
    
    AddTransportProvider: AddTransportProvider,
    
    KYCVerification: KYCVerification,
    
    LinkedAccounts: LinkedAccounts,
    
    CompanyDashboard: CompanyDashboard,
    
    ManageEmployees: ManageEmployees,
    
    RunPayroll: RunPayroll,
    
    EscrowManagement: EscrowManagement,
    
    CreateEscrow: CreateEscrow,
    
    EscrowDetails: EscrowDetails,
    
    EscrowApplication: EscrowApplication,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/SendMoney" element={<SendMoney />} />
                
                <Route path="/Communications" element={<Communications />} />
                
                <Route path="/Rewards" element={<Rewards />} />
                
                <Route path="/History" element={<History />} />
                
                <Route path="/BankDeposit" element={<BankDeposit />} />
                
                <Route path="/RequestMoney" element={<RequestMoney />} />
                
                <Route path="/FleetManagement" element={<FleetManagement />} />
                
                <Route path="/AddVehicle" element={<AddVehicle />} />
                
                <Route path="/MultiWallet" element={<MultiWallet />} />
                
                <Route path="/ScanToPay" element={<ScanToPay />} />
                
                <Route path="/TransportPay" element={<TransportPay />} />
                
                <Route path="/AddTransportProvider" element={<AddTransportProvider />} />
                
                <Route path="/KYCVerification" element={<KYCVerification />} />
                
                <Route path="/LinkedAccounts" element={<LinkedAccounts />} />
                
                <Route path="/CompanyDashboard" element={<CompanyDashboard />} />
                
                <Route path="/ManageEmployees" element={<ManageEmployees />} />
                
                <Route path="/RunPayroll" element={<RunPayroll />} />
                
                <Route path="/EscrowManagement" element={<EscrowManagement />} />
                
                <Route path="/CreateEscrow" element={<CreateEscrow />} />
                
                <Route path="/EscrowDetails" element={<EscrowDetails />} />
                
                <Route path="/EscrowApplication" element={<EscrowApplication />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}