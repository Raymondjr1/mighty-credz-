import React, { useState } from "react";
import { User, Transaction } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Landmark, CheckCircle, AlertCircle, CreditCard } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function BankDeposit() {
  const [amount, setAmount] = useState("");
  const [bankReference, setBankReference] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const [user, setUser] = useState(null);

  React.useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const handleDeposit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");
    
    try {
      const currentUser = await User.me();
      const depositAmount = parseFloat(amount);
      
      if (depositAmount <= 0) {
        throw new Error("Please enter a valid amount");
      }
      
      // Create bank deposit transaction
      await Transaction.create({
        to_user_id: currentUser.id,
        amount: depositAmount,
        type: "bank_deposit",
        status: "completed",
        description: `Bank deposit - EFT Reference: ${bankReference}`,
        bank_reference: bankReference
      });
      
      // Update user's balance
      await User.updateMyUserData({
        wallet_balance: (currentUser.wallet_balance || 0) + depositAmount
      });
      
      setSuccess(true);
      setAmount("");
      setBankReference("");
      
    } catch (error) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <motion.div
          
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          
        >
          <Card className="max-w-md mx-auto text-center bg-white/90 backdrop-blur-sm border-none shadow-2xl">
            <CardContent className="p-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Deposit Confirmed!</h2>
              <p className="text-gray-600 mb-6">
                {amount} CREDz has been successfully deposited to your wallet
              </p>
              <div className="space-y-3">
                <Button 
                  onClick={() => setSuccess(false)}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                >
                  Make Another Deposit
                </Button>
                <Link to={createPageUrl("Dashboard")} className="block">
                  <Button variant="outline" className="w-full">
                    Back to Dashboard
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <motion.div
          
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("Dashboard")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Bank Deposit</h1>
            <p className="text-gray-600">Add money to your Mighty Mobile wallet</p>
          </div>
        </motion.div>

        <motion.div
          
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          
        >
          <Card className="bg-white/90 backdrop-blur-sm border-none shadow-xl mb-6">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Landmark className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl font-bold text-gray-900">
                Deposit Methods
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid gap-4">
                <Alert>
                  <CreditCard className="h-4 w-4" />
                  <AlertDescription className="font-medium">
                    <strong>Your Reference Number:</strong> {user?.phone_number || "Loading..."}
                  </AlertDescription>
                </Alert>
                
                <div className="space-y-4 text-sm text-gray-600">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h3 className="font-semibold text-blue-900 mb-2">🏦 Electronic Funds Transfer (EFT)</h3>
                    <p>Transfer money directly from your bank account using your phone number as reference</p>
                  </div>
                  
                  <div className="p-4 bg-green-50 rounded-lg">
                    <h3 className="font-semibold text-green-900 mb-2">🏧 ATM Deposit</h3>
                    <p>Deposit cash at any participating ATM using your phone number</p>
                  </div>
                  
                  <div className="p-4 bg-purple-50 rounded-lg">
                    <h3 className="font-semibold text-purple-900 mb-2">🏪 Retail Partners</h3>
                    <p>Visit any of our retail partners and deposit cash using your phone number</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/90 backdrop-blur-sm border-none shadow-xl">
            <CardHeader className="text-center pb-2">
              <CardTitle className="text-2xl font-bold text-gray-900">
                Record Your Deposit
              </CardTitle>
              <p className="text-gray-600">Already made a deposit? Record it here</p>
            </CardHeader>
            <CardContent className="p-8">
              {error && (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleDeposit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="amount">Deposit Amount (CREDz)</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    min="0.01"
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="text-lg py-6 text-center font-bold text-2xl"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reference">Bank Reference/Transaction ID</Label>
                  <Input
                    id="reference"
                    placeholder="Enter your bank reference number"
                    value={bankReference}
                    onChange={(e) => setBankReference(e.target.value)}
                    className="py-4"
                    required
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 shadow-lg"
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Processing...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Landmark className="w-5 h-5" />
                      Confirm Deposit
                    </div>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}