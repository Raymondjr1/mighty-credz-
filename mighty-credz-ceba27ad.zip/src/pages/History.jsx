
import React, { useState, useEffect, useCallback } from "react";
import { User, Transaction } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, History as HistoryIcon, ArrowUpRight, ArrowDownLeft, Gift, CreditCard, Search } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { format } from "date-fns";

export default function History() {
  const [transactions, setTransactions] = useState([]);
  const [filteredTransactions, setFilteredTransactions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");

  const loadTransactions = async () => {
    try {
      const currentUser = await User.me();
      const userTransactions = await Transaction.filter(
        { 
          $or: [
            { from_user_id: currentUser.id },
            { to_user_id: currentUser.id }
          ]
        },
        "-created_date",
        100
      );
      setTransactions(userTransactions);
    } catch (error) {
      console.error("Error loading transactions:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const filterTransactions = useCallback(() => {
    let filtered = transactions;

    if (typeFilter !== "all") {
      filtered = filtered.filter(t => t.type === typeFilter);
    }

    if (searchTerm) {
      filtered = filtered.filter(t => 
        t.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.to_phone_number?.includes(searchTerm) ||
        t.vendor_name?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredTransactions(filtered);
  }, [transactions, searchTerm, typeFilter]);

  useEffect(() => {
    loadTransactions();
  }, []);

  useEffect(() => {
    filterTransactions();
  }, [filterTransactions]);

  const getTransactionIcon = (type) => {
    switch (type) {
      case 'send': return <ArrowUpRight className="w-5 h-5 text-red-500" />;
      case 'receive': return <ArrowDownLeft className="w-5 h-5 text-green-500" />;
      case 'reward': return <Gift className="w-5 h-5 text-purple-500" />;
      case 'payment': return <CreditCard className="w-5 h-5 text-blue-500" />;
      default: return <ArrowUpRight className="w-5 h-5" />;
    }
  };

  const getTransactionColor = (type) => {
    switch (type) {
      case 'send': return 'text-red-600';
      case 'receive': return 'text-green-600';
      case 'reward': return 'text-purple-600';
      case 'payment': return 'text-blue-600';
      default: return 'text-gray-600';
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'send': return 'bg-red-100 text-red-800';
      case 'receive': return 'bg-green-100 text-green-800';
      case 'reward': return 'bg-purple-100 text-purple-800';
      case 'payment': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("Dashboard")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Transaction History</h1>
            <p className="text-gray-600">View all your money transfers and rewards</p>
          </div>
        </motion.div>

        {/* Filters */}
        <motion.div
          
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          
          className="mb-8"
        >
          <Card className="bg-white/90 backdrop-blur-sm border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <Input
                      placeholder="Search transactions..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-full md:w-40">
                    <SelectValue placeholder="Filter by type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="send">Sent</SelectItem>
                    <SelectItem value="receive">Received</SelectItem>
                    <SelectItem value="reward">Rewards</SelectItem>
                    <SelectItem value="payment">Payments</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Transactions List */}
        {isLoading ? (
          <div className="space-y-4">
            {Array(5).fill(0).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                    </div>
                    <div className="h-4 bg-gray-200 rounded w-20"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredTransactions.length === 0 ? (
          <motion.div
            
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            
          >
            <Card className="text-center py-12 bg-white/80 backdrop-blur-sm border-none shadow-lg">
              <CardContent>
                <HistoryIcon className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {searchTerm || typeFilter !== "all" ? "No Matching Transactions" : "No Transaction History"}
                </h3>
                <p className="text-gray-600">
                  {searchTerm || typeFilter !== "all" 
                    ? "Try adjusting your search or filter criteria"
                    : "Your transaction history will appear here"
                  }
                </p>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <div className="space-y-4">
            {filteredTransactions.map((transaction, index) => (
              <motion.div
                key={transaction.id}
                
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.05 }}
                
              >
                <Card className="bg-white/90 backdrop-blur-sm border-none shadow-lg hover:shadow-xl transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
                        {getTransactionIcon(transaction.type)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-gray-900">
                            {transaction.description || 
                             (transaction.type === 'send' ? `Sent to ${transaction.to_phone_number}` : 
                              transaction.type === 'receive' ? 'Money Received' :
                              transaction.type === 'reward' ? 'Ad Reward' :
                              transaction.vendor_name || 'Payment')}
                          </h3>
                          <Badge className={getTypeColor(transaction.type)}>
                            {transaction.type}
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <p className="text-sm text-gray-500">
                            {format(new Date(transaction.created_date), "MMM d, yyyy 'at' h:mm a")}
                          </p>
                          <div className={`text-lg font-bold ${getTransactionColor(transaction.type)}`}>
                            {transaction.type === 'send' ? '-' : '+'}${transaction.amount.toFixed(2)}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
