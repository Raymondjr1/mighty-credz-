import React, { useState, useEffect, useCallback } from "react";
import { User, Transaction, TransportProvider } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Bus, Car, CheckCircle, AlertCircle, Send, Search, User as UserIcon, Star } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function TransportPay() {
  const [selectedProvider, setSelectedProvider] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [amount, setAmount] = useState("");
  const [transportProviders, setTransportProviders] = useState([]);
  const [filteredProviders, setFilteredProviders] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const [earnedPoints, setEarnedPoints] = useState(0);

  const loadTransportProviders = async () => {
    try {
      const providers = await TransportProvider.filter({ is_active: true }, "owner_name");
      setTransportProviders(providers);
    } catch (error) {
      console.error("Error loading transport providers:", error);
    }
  };

  const filterProviders = useCallback(() => {
    if (!searchTerm) {
      setFilteredProviders(transportProviders);
    } else {
      const filtered = transportProviders.filter(provider =>
        provider.owner_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        provider.vehicle_registration?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        provider.route?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        provider.company_name?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredProviders(filtered);
    }
  }, [searchTerm, transportProviders]); // Dependencies for useCallback

  useEffect(() => {
    loadTransportProviders();
  }, []);

  useEffect(() => {
    filterProviders();
  }, [filterProviders]); // Dependency for useEffect, using the memoized function

  const handlePayment = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    try {
      const currentUser = await User.me();
      const payAmount = parseFloat(amount);
      const transferFee = 1.15;
      const totalCost = payAmount + transferFee;

      if (payAmount <= 0) throw new Error("Please enter a valid amount");
      if (currentUser.wallet_balance < totalCost) throw new Error(`Insufficient balance. You need ${totalCost.toFixed(2)} CRz (${payAmount} + ${transferFee} transfer fee)`);

      // --- Loyalty Points Logic ---
      const pointsPerCredz = 1; // 1 point per 1 CRz spent
      const pointsEarned = Math.floor(payAmount * pointsPerCredz);
      setEarnedPoints(pointsEarned);

      // Create transaction to transport provider
      await Transaction.create({
        from_user_id: currentUser.id,
        from_phone_number: currentUser.phone_number,
        to_phone_number: selectedProvider.phone_number,
        to_user_id: selectedProvider.account_id,
        amount: payAmount,
        transfer_fee: transferFee,
        type: "payment",
        payment_method: "transport",
        vendor_name: selectedProvider.owner_name,
        description: `${selectedProvider.transport_type.toUpperCase()} fare to ${selectedProvider.owner_name}`,
        status: "completed",
        loyalty_points_earned: pointsEarned
      });

      // Update sender's balance and loyalty points
      await User.updateMyUserData({
        wallet_balance: currentUser.wallet_balance - totalCost,
        total_loyalty_points: (currentUser.total_loyalty_points || 0) + pointsEarned,
      });

      setSuccess(true);
      setAmount("");
    } catch (e) {
      setError(e.message);
    } finally {
      setIsLoading(false);
    }
  };

  const getTransportIcon = (type) => {
    switch (type) {
      case 'taxi': case 'uber': case 'bolt': return Car;
      case 'kombi': case 'bus': case 'private_transport': return Bus;
      default: return Car;
    }
  };

  const getTransportColor = (type) => {
    switch (type) {
      case 'uber': return 'bg-black text-white';
      case 'bolt': return 'bg-green-500 text-white';
      case 'taxi': return 'bg-yellow-500 text-white';
      case 'kombi': return 'bg-blue-500 text-white';
      case 'bus': return 'bg-red-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
          <Card className="max-w-md mx-auto text-center mighty-surface mighty-shadow-slate border-none">
            <CardContent className="p-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Payment Successful!</h2>
              <p className="text-gray-600 mb-2">
                You paid <span className="font-bold text-green-600">{parseFloat(amount).toFixed(2)} CRz</span> to
              </p>
              <p className="font-bold text-lg text-gray-900 mb-2">
                {selectedProvider.owner_name}
              </p>
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-3 my-4">
                <div className="flex items-center justify-center gap-2">
                  <Star className="w-5 h-5 text-purple-500" />
                  <span className="font-bold text-purple-700">You earned {earnedPoints} loyalty points!</span>
                </div>
              </div>
              <div className="space-y-3">
                <Button 
                  onClick={() => { 
                    setSuccess(false); 
                    setSelectedProvider(null); 
                    setAmount(""); 
                    setEarnedPoints(0);
                  }}
                  className="w-full mighty-button-primary"
                >
                  New Payment
                </Button>
                <Link to={createPageUrl("Dashboard")}>
                  <Button variant="outline" className="w-full">
                    Back to Dashboard
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("Dashboard")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Transport Payments</h1>
            <p className="text-gray-600">Pay taxi, kombi, Uber & Bolt drivers directly</p>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          {selectedProvider ? (
            <Card className="mighty-surface mighty-shadow border-none">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  {React.createElement(getTransportIcon(selectedProvider.transport_type), { 
                    className: "w-8 h-8 text-blue-600" 
                  })}
                </div>
                <CardTitle>Pay Transport Provider</CardTitle>
                <div className="space-y-2">
                  <p className="text-xl font-bold text-gray-900">{selectedProvider.owner_name}</p>
                  <div className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${getTransportColor(selectedProvider.transport_type)}`}>
                    {selectedProvider.transport_type.toUpperCase()}
                  </div>
                  <p className="text-gray-600">{selectedProvider.phone_number}</p>
                  {selectedProvider.vehicle_registration && (
                    <p className="text-gray-500 text-sm">Vehicle: {selectedProvider.vehicle_registration}</p>
                  )}
                  {selectedProvider.route && (
                    <p className="text-gray-500 text-sm">Route: {selectedProvider.route}</p>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <form onSubmit={handlePayment} className="space-y-6">
                  {error && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}
                  
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      Transfer fee of <strong>1.15 CRz</strong> will be added to your payment
                    </AlertDescription>
                  </Alert>

                  <div className="space-y-2">
                    <Label htmlFor="amount">Fare Amount (CRz)</Label>
                    <Input
                      id="amount"
                      type="number"
                      step="0.01"
                      min="0.01"
                      placeholder="0.00"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="text-4xl text-center font-bold h-20"
                      required
                    />
                  </div>
                  
                  {amount && (
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex justify-between mb-2">
                        <span>Fare Amount:</span>
                        <span className="font-medium">{parseFloat(amount || 0).toFixed(2)} CRz</span>
                      </div>
                      <div className="flex justify-between mb-2">
                        <span>Transfer Fee:</span>
                        <span className="font-medium">1.15 CRz</span>
                      </div>
                      <hr className="my-2" />
                      <div className="flex justify-between font-bold">
                        <span>Total Cost:</span>
                        <span>{(parseFloat(amount || 0) + 1.15).toFixed(2)} CRz</span>
                      </div>
                    </div>
                  )}

                  <div className="flex gap-3">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setSelectedProvider(null)}
                      className="flex-1"
                    >
                      Back
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={isLoading} 
                      className="flex-1 mighty-button-primary"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      {isLoading ? "Processing..." : "Pay Now"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {/* Search for Transport Provider */}
              <Card className="mighty-surface mighty-shadow border-none">
                <CardHeader>
                  <CardTitle>Find Transport Provider</CardTitle>
                  <p className="text-gray-600">Search by driver name, vehicle plate, or route</p>
                </CardHeader>
                <CardContent>
                  <div className="relative">
                    <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <Input
                      placeholder="Search driver name, vehicle plate, or route..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Transport Providers List */}
              <Card className="mighty-surface mighty-shadow border-none">
                <CardHeader>
                  <CardTitle>Available Transport Providers</CardTitle>
                </CardHeader>
                <CardContent>
                  {filteredProviders.length === 0 ? (
                    <div className="text-center py-8">
                      <Bus className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        {searchTerm ? "No providers found" : "No transport providers available"}
                      </h3>
                      <p className="text-gray-600">
                        {searchTerm ? "Try a different search term" : "Transport providers will appear here when they join the network"}
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {filteredProviders.map((provider, index) => {
                        const TransportIcon = getTransportIcon(provider.transport_type);
                        return (
                          <motion.div
                            key={provider.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="p-4 border border-gray-200 rounded-xl hover:shadow-md transition-all cursor-pointer"
                            onClick={() => setSelectedProvider(provider)}
                          >
                            <div className="flex items-center gap-4">
                              <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center">
                                <TransportIcon className="w-6 h-6 text-gray-600" />
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <h3 className="font-semibold text-gray-900">{provider.owner_name}</h3>
                                  {provider.is_verified && (
                                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                                  )}
                                </div>
                                <div className="flex items-center gap-2 text-sm text-gray-600">
                                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTransportColor(provider.transport_type)}`}>
                                    {provider.transport_type.toUpperCase()}
                                  </span>
                                  {provider.vehicle_registration && (
                                    <span>{provider.vehicle_registration}</span>
                                  )}
                                </div>
                                {provider.route && (
                                  <p className="text-sm text-gray-500 mt-1">Route: {provider.route}</p>
                                )}
                                {provider.company_name && (
                                  <p className="text-sm text-gray-500 mt-1">{provider.company_name}</p>
                                )}
                                <p className="text-xs text-gray-400 mt-1">{provider.phone_number}</p>
                              </div>
                              <div className="text-right">
                                <Button size="sm" className="mighty-button-primary">
                                  Select & Pay
                                </Button>
                              </div>
                            </div>
                          </motion.div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}