import React, { useState, useEffect } from "react";
import { User, LinkedAccount } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Link2, Plus, Banknote, CreditCard, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function LinkedAccounts() {
  const [accounts, setAccounts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState(null);
  
  // Form state
  const [accountType, setAccountType] = useState("");
  const [providerName, setProviderName] = useState("");
  const [accountDetails, setAccountDetails] = useState("");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      const linkedAccounts = await LinkedAccount.filter({ user_id: currentUser.id }, "-created_date");
      setAccounts(linkedAccounts);
    } catch (e) {
      console.error("Failed to fetch data", e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddAccount = async () => {
    if (!accountType || !providerName || !accountDetails) {
      alert("Please fill all fields");
      return;
    }
    try {
      await LinkedAccount.create({
        user_id: user.id,
        account_type: accountType,
        provider_name: providerName,
        account_details: accountDetails,
      });
      // Reset form and refetch
      setAccountType("");
      setProviderName("");
      setAccountDetails("");
      fetchData();
    } catch (error) {
      console.error("Failed to add account", error);
    }
  };
  
  const handleDeleteAccount = async (accountId) => {
    if (window.confirm("Are you sure you want to unlink this account?")) {
        try {
            await LinkedAccount.delete(accountId);
            fetchData();
        } catch (error) {
            console.error("Failed to delete account", error);
        }
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Dashboard")}>
              <Button variant="outline" size="icon" className="rounded-full">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Linked Accounts</h1>
              <p className="text-gray-600">Manage your connected banks and payment gateways.</p>
            </div>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button className="mighty-button-primary">
                <Plus className="w-4 h-4 mr-2" />
                Link New Account
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Link a New Financial Account</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <Alert variant="warning">
                  <AlertDescription>
                    <strong>Demonstration Only:</strong> This is a simulation. Do not enter real financial information. Real integrations would require a secure connection to your financial institution.
                  </AlertDescription>
                </Alert>
                <div className="space-y-2">
                  <Label>Account Type</Label>
                  <Select onValueChange={setAccountType} value={accountType}>
                    <SelectTrigger><SelectValue placeholder="Select account type..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bank_account">Bank Account</SelectItem>
                      <SelectItem value="payment_gateway">Payment Gateway</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="provider_name">Provider Name</Label>
                  <Input id="provider_name" placeholder="e.g., FNB, Absa, PayPal" value={providerName} onChange={e => setProviderName(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="account_details">Account Details</Label>
                  <Input id="account_details" placeholder="e.g., Savings **** 1234" value={accountDetails} onChange={e => setAccountDetails(e.target.value)} />
                </div>
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button type="button" onClick={handleAddAccount}>Link Account</Button>
                </DialogClose>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </motion.div>
        
        {isLoading ? (
          <p>Loading...</p>
        ) : accounts.length === 0 ? (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
             <Card className="text-center py-12 mighty-surface">
                <CardContent>
                    <Link2 className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No Accounts Linked</h3>
                    <p className="text-gray-600">Link a bank account or payment gateway to easily move money.</p>
                </CardContent>
            </Card>
          </motion.div>
        ) : (
          <div className="space-y-4">
            {accounts.map((account, index) => (
              <motion.div
                key={account.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="mighty-surface hover:shadow-lg transition-shadow">
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                        {account.account_type === 'bank_account' ? <Banknote className="w-6 h-6 text-gray-600" /> : <CreditCard className="w-6 h-6 text-gray-600" />}
                      </div>
                      <div>
                        <p className="font-bold text-lg">{account.provider_name}</p>
                        <p className="text-gray-600">{account.account_details}</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => handleDeleteAccount(account.id)}>
                        <Trash2 className="w-5 h-5 text-red-500" />
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}