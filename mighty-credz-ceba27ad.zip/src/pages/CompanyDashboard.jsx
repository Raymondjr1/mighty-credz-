import React from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Briefcase, DollarSign, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function CompanyDashboard() {
  const actions = [
    {
      title: "Manage Employees",
      description: "Onboard staff and set permissions.",
      icon: Users,
      url: "ManageEmployees",
      color: "from-blue-500 to-indigo-600"
    },
    {
      title: "Run Payroll",
      description: "Pay salaries to your employees instantly.",
      icon: DollarSign,
      url: "RunPayroll",
      color: "from-green-500 to-emerald-600"
    },
    {
      title: "Company Fleet",
      description: "Manage all company vehicles and fuel.",
      icon: Briefcase,
      url: "FleetManagement",
      color: "from-purple-500 to-violet-600"
    }
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("Dashboard")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Company Hub</h1>
            <p className="text-gray-600">Your central dashboard for business operations.</p>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {actions.map((action, index) => (
            <motion.div
              key={action.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * (index + 1) }}
            >
              <Link to={createPageUrl(action.url)}>
                <Card className="h-full mighty-card-hover flex flex-col justify-between mighty-surface">
                    <CardHeader>
                        <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${action.color} flex items-center justify-center mb-4`}>
                            <action.icon className="w-6 h-6 text-white" />
                        </div>
                        <CardTitle>{action.title}</CardTitle>
                        <CardDescription>{action.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                       <Button variant="link" className="p-0">Go to {action.title} &rarr;</Button>
                    </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}