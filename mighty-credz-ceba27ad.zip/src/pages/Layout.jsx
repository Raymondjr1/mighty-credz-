

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { 
  Wallet, 
  MessageSquare, 
  Gift, 
  History, 
  Home,
  Menu,
  X,
  Landmark,
  HandCoins,
  Send,
  Car,
  WalletCards,
  QrCode,
  Bus,
  ShieldCheck,
  Building,
  Briefcase,
  Link2,
  Shield // Added Shield icon
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";

const individualNav = [
  { title: "Dashboard", url: "Dashboard", icon: Home },
  { title: "Scan to Pay", url: "ScanToPay", icon: QrCode },
  { title: "Transport Pay", url: "TransportPay", icon: Bus },
  { title: "Escrow Service", url: "EscrowManagement", icon: Shield }, // Added Escrow Service
  { title: "Fleet Management", url: "FleetManagement", icon: Car },
  { title: "Multi-Wallets", url: "MultiWallet", icon: WalletCards },
  { title: "Send Money", url: "SendMoney", icon: Send },
  { title: "Request Money", url: "RequestMoney", icon: HandCoins },
  { title: "Bank Deposit", url: "BankDeposit", icon: Landmark },
  { title: "Communications", url: "Communications", icon: MessageSquare },
  { title: "Rewards & TLC", url: "Rewards", icon: Gift },
  { title: "KYC Verification", url: "KYCVerification", icon: ShieldCheck },
  { title: "Linked Accounts", url: "LinkedAccounts", icon: Link2 },
];

const companyNav = [
  { title: "Dashboard", url: "Dashboard", icon: Home },
  { title: "Company Hub", url: "CompanyDashboard", icon: Building },
  { title: "Escrow Service", url: "EscrowManagement", icon: Shield }, // Added Escrow Service
  { title: "Fleet Management", url: "FleetManagement", icon: Car },
  { title: "Bank Deposit", url: "BankDeposit", icon: Landmark },
  { title: "Communications", url: "Communications", icon: MessageSquare },
  { title: "Linked Accounts", url: "LinkedAccounts", icon: Link2 },
];


export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const [user, setUser] = useState(null);
  const [navigationItems, setNavigationItems] = useState(individualNav);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
        if (currentUser.account_type === 'company') {
          setNavigationItems(companyNav);
        } else {
          setNavigationItems(individualNav);
        }
      } catch (error) {
        // Not logged in, default to individual nav
        setNavigationItems(individualNav);
      }
    };
    fetchUser();
  }, []);
  
  const mappedNavItems = navigationItems.map(item => ({...item, url: createPageUrl(item.url)}));

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-slate-50 via-teal-50 to-slate-100">
        <style>
          {`
            :root {
              --mighty-teal: #5CBAA5;
              --mighty-teal-light: #7DCCB8;
              --mighty-teal-dark: #4A9B89;
              --mighty-slate: #4A5568;
              --mighty-slate-light: #718096;
              --mighty-slate-dark: #2D3748;
              --mighty-white: #FFFFFF;
              --mighty-gray-50: #F8FAFC;
              --mighty-gray-100: #F1F5F9;
              --mighty-gray-200: #E2E8F0;
              --mighty-success: #10B981;
              --mighty-warning: #F59E0B;
              --mighty-error: #EF4444;
              --mighty-surface: rgba(255, 255, 255, 0.95);
              --mighty-surface-dark: rgba(74, 85, 104, 0.95);
            }

            .mighty-gradient-primary {
              background: linear-gradient(135deg, var(--mighty-teal), var(--mighty-teal-light));
            }

            .mighty-gradient-secondary {
              background: linear-gradient(135deg, var(--mighty-slate), var(--mighty-slate-light));
            }

            .mighty-gradient-hero {
              background: linear-gradient(135deg, var(--mighty-teal) 0%, var(--mighty-slate) 100%);
            }

            .mighty-surface {
              background: var(--mighty-surface);
              backdrop-filter: blur(12px);
              border: 1px solid rgba(92, 186, 165, 0.1);
            }

            .mighty-shadow {
              box-shadow: 0 8px 32px rgba(92, 186, 165, 0.15);
            }

            .mighty-shadow-slate {
              box-shadow: 0 8px 32px rgba(74, 85, 104, 0.15);
            }

            .credz-currency::after {
              content: " CRz";
              font-weight: 600;
              color: var(--mighty-teal);
            }

            .fuel-rebate-highlight {
              background: linear-gradient(135deg, var(--mighty-warning), #F97316);
              color: white;
            }

            .tlc-highlight {
              background: linear-gradient(135deg, var(--mighty-teal), var(--mighty-teal-light));
              color: white;
            }

            .fleet-highlight {
              background: linear-gradient(135deg, var(--mighty-slate), var(--mighty-slate-light));
              color: white;
            }

            .mighty-card-hover {
              transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            }

            .mighty-card-hover:hover {
              transform: translateY(-4px);
              box-shadow: 0 20px 40px rgba(92, 186, 165, 0.2);
            }

            .mighty-button-primary {
              background: var(--mighty-gradient-primary);
              border: none;
              color: white;
              font-weight: 600;
              transition: all 0.3s ease;
            }

            .mighty-button-primary:hover {
              background: linear-gradient(135deg, var(--mighty-teal-dark), var(--mighty-teal));
              transform: translateY(-1px);
              box-shadow: 0 8px 20px rgba(92, 186, 165, 0.3);
            }
          `}
        </style>

        {/* Desktop Sidebar */}
        <Sidebar className="border-r border-teal-100/50 mighty-surface hidden md:flex">
          <SidebarHeader className="p-6 border-b border-teal-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center mighty-shadow overflow-hidden">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68b849779568f82bceba27ad/8724df0d4_299191826_480308234104623_1691308453234998382_n.jpg" 
                  alt="Mighty Mobile Logo" 
                  className="w-10 h-10 object-contain"
                />
              </div>
              <div>
                <h2 className="font-bold text-xl text-slate-800">Mighty Mobile</h2>
                <p className="text-xs text-teal-600 font-medium">{user?.account_type === 'company' ? (user.company_name || 'Company Hub') : 'Fleet & Business Ecosystem'}</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-4">
            <SidebarGroup>
              <SidebarGroupContent>
                <SidebarMenu className="space-y-2">
                  {mappedNavItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`
                          rounded-xl px-4 py-3 transition-all duration-300 hover:mighty-gradient-primary hover:text-white hover:shadow-lg group
                          ${location.pathname === item.url 
                            ? 'mighty-gradient-primary text-white mighty-shadow' 
                            : 'text-slate-700 hover:bg-teal-50'
                          }
                        `}
                      >
                        <Link to={item.url} className="flex items-center gap-3">
                          <item.icon className="w-5 h-5" />
                          <span className="font-medium">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            {/* Brand Feature Highlights */}
            <SidebarGroup>
              <div className="px-3 py-4 space-y-3">
                <div className="fuel-rebate-highlight p-3 rounded-xl text-center text-sm mighty-shadow">
                  <div className="font-bold">⛽ Fuel Rebate</div>
                  <div className="text-xs opacity-90">0.50 CRz per liter</div>
                </div>
                
                <div className="tlc-highlight p-3 rounded-xl text-center text-sm mighty-shadow">
                  <div className="font-bold">🎯 TLC Program</div>
                  <div className="text-xs opacity-90">Earn from referrals</div>
                </div>

                <div className="fleet-highlight p-3 rounded-xl text-center text-sm mighty-shadow">
                  <div className="font-bold">🚗 Fleet Benefits</div>
                  <div className="text-xs opacity-90">Corporate fuel rates</div>
                </div>
              </div>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>

        {/* Mobile Navigation */}
        <div className="md:hidden fixed top-0 left-0 right-0 z-50 mighty-surface border-b border-teal-200">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center overflow-hidden">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68b849779568f82bceba27ad/8724df0d4_299191826_480308234104623_1691308453234998382_n.jpg" 
                  alt="Mighty Mobile Logo" 
                  className="w-6 h-6 object-contain"
                />
              </div>
              <h2 className="font-bold text-lg text-slate-800">Mighty Mobile</h2>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-slate-600 hover:bg-teal-50"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
          
          {isMobileMenuOpen && (
            <div className="absolute top-full left-0 right-0 mighty-surface shadow-lg border-b border-teal-200">
              <div className="p-4 space-y-2">
                {mappedNavItems.map((item) => (
                  <Link
                    key={item.title}
                    to={item.url}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`
                      flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300
                      ${location.pathname === item.url 
                        ? 'mighty-gradient-primary text-white' 
                        : 'text-slate-700 hover:bg-teal-50'
                      }
                    `}
                  >
                    <item.icon className="w-5 h-5" />
                    <span className="font-medium">{item.title}</span>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Main content area */}
        <main className="flex-1 flex flex-col pt-16 md:pt-0">
          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}

