import React, { useState } from "react";
import { User, MoneyRequest } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, HandCoins, CheckCircle, AlertCircle, Building2 } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function RequestMoney() {
  const [phoneNumber, setPhoneNumber] = useState("");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const [user, setUser] = useState(null);

  React.useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const handleRequestMoney = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");
    
    try {
      const currentUser = await User.me();
      const requestAmount = parseFloat(amount);
      
      if (requestAmount <= 0) {
        throw new Error("Please enter a valid amount");
      }

      // Check if user is authorized to request money
      if (currentUser.account_type === 'individual' && !currentUser.is_authorized_employee) {
        throw new Error("Individuals cannot request money. Only companies and authorized employees can make money requests.");
      }
      
      // Create money request
      const expiryDate = new Date();
      expiryDate.setHours(expiryDate.getHours() + 24); // 24 hour expiry
      
      await MoneyRequest.create({
        requester_id: currentUser.id,
        requester_phone: currentUser.phone_number,
        requester_name: currentUser.full_name,
        target_phone: phoneNumber,
        amount: requestAmount,
        description: description || `Money request from ${currentUser.account_type === 'company' ? currentUser.company_name : currentUser.full_name}`,
        status: "pending",
        expiry_date: expiryDate.toISOString(),
        is_company_request: currentUser.account_type === 'company',
        company_name: currentUser.company_name
      });
      
      setSuccess(true);
      setPhoneNumber("");
      setAmount("");
      setDescription("");
      
    } catch (error) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <motion.div
          
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          
        >
          <Card className="max-w-md mx-auto text-center bg-white/90 backdrop-blur-sm border-none shadow-2xl">
            <CardContent className="p-8">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-blue-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Request Sent!</h2>
              <p className="text-gray-600 mb-6">
                Your request for {amount} CREDz has been sent to {phoneNumber}
              </p>
              <div className="space-y-3">
                <Button 
                  onClick={() => setSuccess(false)}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                >
                  Make Another Request
                </Button>
                <Link to={createPageUrl("Dashboard")} className="block">
                  <Button variant="outline" className="w-full">
                    Back to Dashboard
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  // Check if user can request money
  const canRequestMoney = user?.account_type === 'company' || user?.is_authorized_employee;

  if (!canRequestMoney) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md mx-auto text-center bg-white/90 backdrop-blur-sm border-none shadow-2xl">
          <CardContent className="p-8">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-8 h-8 text-orange-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Access Restricted</h2>
            <p className="text-gray-600 mb-6">
              Only companies and authorized employees can request money from others. Individuals can only initiate transactions to prevent abuse.
            </p>
            <Link to={createPageUrl("Dashboard")}>
              <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                Back to Dashboard
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <motion.div
          
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          
          className="flex items-center gap-4 mb-8"
        >
          <Link to={createPageUrl("Dashboard")}>
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Request Money</h1>
            <p className="text-gray-600">Request CREDz from another user</p>
          </div>
        </motion.div>

        <motion.div
          
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          
        >
          <Card className="bg-white/90 backdrop-blur-sm border-none shadow-xl">
            <CardHeader className="text-center pb-2">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                {user?.account_type === 'company' ? (
                  <Building2 className="w-8 h-8 text-white" />
                ) : (
                  <HandCoins className="w-8 h-8 text-white" />
                )}
              </div>
              <CardTitle className="text-2xl font-bold text-gray-900">
                Request CREDz
              </CardTitle>
              {user?.account_type === 'company' && (
                <p className="text-blue-600 font-medium">{user.company_name}</p>
              )}
            </CardHeader>
            <CardContent className="p-8">
              <Alert className="mb-6">
                <HandCoins className="h-4 w-4" />
                <AlertDescription>
                  As a {user?.account_type === 'company' ? 'company' : 'authorized employee'}, you can request money from other users. 
                  The recipient will need to approve your request. Transfer fee of 1.15 CREDz will be charged to the sender.
                </AlertDescription>
              </Alert>

              {error && (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleRequestMoney} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="phone">Request From (Phone Number)</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+1 (555) 123-4567"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="text-lg py-6"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="amount">Amount (CREDz)</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    min="0.01"
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="text-lg py-6 text-center font-bold text-2xl"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Reason for Request</Label>
                  <Input
                    id="description"
                    placeholder="What is this request for?"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="py-4"
                    required
                  />
                </div>

                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-sm">
                    The recipient will receive your request and can choose to approve or decline. 
                    Requests expire after 24 hours.
                  </AlertDescription>
                </Alert>

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg"
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Sending Request...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <HandCoins className="w-5 h-5" />
                      Send Money Request
                    </div>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}