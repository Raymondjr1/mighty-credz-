import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ArrowLeft, UserPlus, Shield } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function ManageEmployees() {
  const [employees, setEmployees] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [company, setCompany] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const currentUser = await User.me();
        setCompany(currentUser);
        const companyEmployees = await User.filter({ parent_company_id: currentUser.id });
        setEmployees(companyEmployees);
      } catch (error) {
        console.error("Error fetching employee data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("CompanyDashboard")}>
              <Button variant="outline" size="icon" className="rounded-full">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Manage Employees</h1>
              <p className="text-gray-600">View, invite, and manage permissions for your staff.</p>
            </div>
          </div>
          <Button className="mighty-button-primary">
            <UserPlus className="w-4 h-4 mr-2" />
            Invite Employee
          </Button>
        </motion.div>
        
        {isLoading ? (
          <p>Loading employees...</p>
        ) : employees.length === 0 ? (
          <Card className="text-center py-12 mighty-surface">
            <CardContent>
              <h3 className="text-xl font-semibold">No Employees Found</h3>
              <p className="text-gray-600 mt-2 mb-4">Invite your first employee to get started.</p>
              <Button>Invite Employee</Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {employees.map((employee, index) => (
              <motion.div
                key={employee.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="mighty-surface">
                  <CardContent className="p-4 flex items-center justify-between">
                    <div>
                      <p className="font-bold">{employee.full_name}</p>
                      <p className="text-sm text-gray-500">{employee.email}</p>
                      <p className="text-sm text-gray-500">{employee.phone_number}</p>
                    </div>
                    <div className="flex items-center gap-2">
                        <p className="text-sm font-medium text-gray-700">{employee.employee_category || 'Employee'}</p>
                        <Button variant="outline" size="sm">
                            <Shield className="w-4 h-4 mr-2" />
                            Permissions
                        </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}