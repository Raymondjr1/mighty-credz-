import { base44 } from './base44Client';


export const Transaction = base44.entities.Transaction;

export const Communication = base44.entities.Communication;

export const Advertisement = base44.entities.Advertisement;

export const MoneyRequest = base44.entities.MoneyRequest;

export const Vehicle = base44.entities.Vehicle;

export const FuelTransaction = base44.entities.FuelTransaction;

export const Wallet = base44.entities.Wallet;

export const LoyaltyProgram = base44.entities.LoyaltyProgram;

export const TransportProvider = base44.entities.TransportProvider;

export const LinkedAccount = base44.entities.LinkedAccount;

export const PayrollRun = base44.entities.PayrollRun;

export const PayrollEmployeePayment = base44.entities.PayrollEmployeePayment;

export const EscrowAccount = base44.entities.EscrowAccount;

export const TradeDocument = base44.entities.TradeDocument;

export const DisputeResolution = base44.entities.DisputeResolution;



// auth sdk:
export const User = base44.auth;