import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Wallet, Send, Download, Eye, EyeOff } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function WalletCard({ balance, showBalance, setShowBalance }) {
  return (
    <motion.div
      
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      
    >
      <Card className="mighty-gradient-hero text-white border-none mighty-shadow-slate">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68b849779568f82bceba27ad/8724df0d4_299191826_480308234104623_1691308453234998382_n.jpg" 
                  alt="Mighty Mobile" 
                  className="w-8 h-8 object-contain opacity-90"
                />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Treasury Wallet</h3>
                <p className="text-teal-100 text-sm">CREDz Balance</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowBalance(!showBalance)}
              className="text-white hover:bg-white/20"
            >
              {showBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="text-5xl font-bold mb-2">
              {showBalance ? `${balance.toFixed(2)}` : "••••"}
            </div>
            <p className="text-teal-100 text-lg font-medium">CREDz</p>
          </div>
          
          <div className="flex gap-3">
            <Link to={createPageUrl("SendMoney")} className="flex-1">
              <Button className="w-full bg-white/20 hover:bg-white/30 text-white border-none backdrop-blur-sm transition-all duration-300 hover:transform hover:scale-105">
                <Send className="w-4 h-4 mr-2" />
                Send Money
              </Button>
            </Link>
            <Link to={createPageUrl("BankDeposit")} className="flex-1">
              <Button className="w-full bg-white/20 hover:bg-white/30 text-white border-none backdrop-blur-sm transition-all duration-300 hover:transform hover:scale-105">
                <Download className="w-4 h-4 mr-2" />
                Deposit
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}