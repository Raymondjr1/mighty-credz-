import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from "@/components/ui/card";
import { MessageSquare, Gift, History, CreditCard, Landmark, HandCoins, Car, Wallet, QrCode, Bus, Shield } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const actions = [
  {
    title: "Scan to Pay",
    description: "Instant QR payments",
    icon: QrCode,
    url: "ScanToPay",
    color: "mighty-gradient-secondary"
  },
  {
    title: "Transport Pay",
    description: "Uber • Bolt • Taxi",
    icon: Bus,
    url: "TransportPay",
    color: "bg-gradient-to-br from-amber-500 to-orange-600"
  },
  {
    title: "Escrow Service",
    description: "Secure trade protection",
    icon: Shield,
    url: "EscrowManagement",
    color: "bg-gradient-to-br from-emerald-500 to-teal-600"
  },
  {
    title: "Fleet Management",
    description: "Vehicles & fuel rebates",
    icon: Car,
    url: "FleetManagement",
    color: "fleet-highlight"
  },
  {
    title: "Multi-Wallets",
    description: "Organize your CREDz",
    icon: Wallet,
    url: "MultiWallet",
    color: "mighty-gradient-primary"
  },
  {
    title: "Bank Deposit",
    description: "EFT • ATM • Retail",
    icon: Landmark,
    url: "BankDeposit",
    color: "bg-gradient-to-br from-green-500 to-emerald-600"
  },
  {
    title: "Request Money",
    description: "Request CREDz",
    icon: HandCoins,
    url: "RequestMoney",
    color: "bg-gradient-to-br from-blue-500 to-indigo-600"
  },
  {
    title: "Communications",
    description: "Free messaging",
    icon: MessageSquare,
    url: "Communications",
    color: "bg-gradient-to-br from-purple-500 to-violet-600"
  },
  {
    title: "Rewards & TLC",
    description: "Earn & refer friends",
    icon: Gift,
    url: "Rewards", 
    color: "tlc-highlight"
  }
];

export default function QuickActions() {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
      {actions.map((action, index) => (
        <motion.div
          key={action.title}
          
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: index * 0.05 }}
          
        >
          <Link to={createPageUrl(action.url)}>
            <Card className="mighty-card-hover cursor-pointer border-none overflow-hidden h-full mighty-surface mighty-shadow">
              <CardContent className="p-0 flex flex-col h-full">
                <div className={`${action.color} p-6 text-white flex-grow flex flex-col justify-between min-h-[140px]`}>
                  <div>
                    <action.icon className="w-8 h-8 mb-3" />
                    <h3 className="font-semibold text-lg mb-1 leading-tight">{action.title}</h3>
                  </div>
                  <p className="text-white/90 text-sm leading-tight">{action.description}</p>
                </div>
              </CardContent>
            </Card>
          </Link>
        </motion.div>
      ))}
    </div>
  );
}