
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, ArrowDownLeft, Gift, CreditCard, Star } from "lucide-react";
import { format } from "date-fns";

const getTransactionIcon = (type) => {
  switch (type) {
    case 'send': return <ArrowUpRight className="w-4 h-4 text-red-500" />;
    case 'receive': return <ArrowDownLeft className="w-4 h-4 text-green-500" />;
    case 'reward': return <Gift className="w-4 h-4 text-purple-500" />;
    case 'payment': return <CreditCard className="w-4 h-4 text-blue-500" />;
    default: return <ArrowUpRight className="w-4 h-4" />;
  }
};

const getTransactionColor = (type) => {
  switch (type) {
    case 'send': return 'text-red-600';
    case 'receive': return 'text-green-600';
    case 'reward': return 'text-purple-600';
    case 'payment': return 'text-blue-600';
    default: return 'text-gray-600';
  }
};

export default function RecentActivity({ transactions, isLoading }) {
  if (isLoading) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-none shadow-lg">
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="flex items-center gap-4 animate-pulse">
                <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
                <div className="h-4 bg-gray-200 rounded w-16"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.3 }}
      
    >
      <Card className="bg-white/80 backdrop-blur-sm border-none shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-900">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          {transactions.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <CreditCard className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p>No recent transactions</p>
            </div>
          ) : (
            <div className="space-y-4">
              {transactions.slice(0, 5).map((transaction, index) => (
                <motion.div
                  key={transaction.id}
                  
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  
                  className="flex items-center gap-4 p-3 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                    {getTransactionIcon(transaction.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-gray-900">
                        {transaction.type === 'send' ? 'Sent to' : 
                         transaction.type === 'receive' ? 'Received from' :
                         transaction.type === 'reward' ? 'Ad Reward' :
                         transaction.vendor_name || 'Payment'}
                      </p>
                      <Badge variant="secondary" className="text-xs">
                        {transaction.type}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-500">
                      {format(new Date(transaction.created_date), "MMM d, yyyy")}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className={`font-semibold ${getTransactionColor(transaction.type)}`}>
                      {transaction.type === 'send' ? '-' : '+'}${transaction.amount.toFixed(2)}
                    </div>
                    {transaction.loyalty_points_earned > 0 && (
                       <div className="flex items-center justify-end gap-1 text-xs text-purple-600">
                         <Star className="w-3 h-3" />
                         <span>+{transaction.loyalty_points_earned} pts</span>
                       </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
